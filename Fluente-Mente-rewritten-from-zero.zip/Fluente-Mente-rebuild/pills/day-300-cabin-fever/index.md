---
layout: article
title: Cabin fever — una espressione da usare davvero
description: Imparare a usare naturalmente “cabin fever” nella situazione collegata.
content_id: PILL300
content_type: daily_pill
permalink: /pills/day-300-cabin-fever/
canonical: /pills/day-300-cabin-fever/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Cabin fever — una espressione da usare davvero
toc: true
level: B2
day: 300
expression_id: EXP300
situation_id: SIT044
grammar_id: GRAM044
category: Idiom
type: noun phrase
topic: Feelings & Daily Life
learning_goal: Imparare a usare naturalmente “cabin fever” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART044
- GRAMART044
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
