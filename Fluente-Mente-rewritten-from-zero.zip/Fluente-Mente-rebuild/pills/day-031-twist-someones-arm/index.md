---
layout: article
title: Twist someone's arm — una espressione da usare davvero
description: Imparare a usare naturalmente “twist someone's arm” nella situazione
  collegata.
content_id: PILL031
content_type: daily_pill
permalink: /pills/day-031-twist-someones-arm/
canonical: /pills/day-031-twist-someones-arm/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Twist someone's arm — una espressione da usare davvero
toc: true
level: B1
day: 31
expression_id: EXP031
situation_id: SIT007
grammar_id: GRAM007
category: Idiom
type: idiom
topic: Persuasion
learning_goal: Imparare a usare naturalmente “twist someone's arm” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART007
- GRAMART007
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
