---
layout: article
title: Thirsty — una espressione da usare davvero
description: Imparare a usare naturalmente “thirsty” nella situazione collegata.
content_id: PILL281
content_type: daily_pill
permalink: /pills/day-281-thirsty/
canonical: /pills/day-281-thirsty/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Thirsty — una espressione da usare davvero
toc: true
level: B2
day: 281
expression_id: EXP281
situation_id: SIT048
grammar_id: GRAM048
category: Slang / Internet English
type: adjective
topic: Social Media & Behaviour
learning_goal: Imparare a usare naturalmente “thirsty” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART048
- GRAMART048
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
