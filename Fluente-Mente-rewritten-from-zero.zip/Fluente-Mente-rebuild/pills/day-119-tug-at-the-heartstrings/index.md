---
layout: article
title: Tug at the heartstrings — una espressione da usare davvero
description: Imparare a usare naturalmente “tug at the heartstrings” nella situazione
  collegata.
content_id: PILL119
content_type: daily_pill
permalink: /pills/day-119-tug-at-the-heartstrings/
canonical: /pills/day-119-tug-at-the-heartstrings/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Tug at the heartstrings — una espressione da usare davvero
toc: true
level: B2
day: 119
expression_id: EXP119
situation_id: SIT044
grammar_id: GRAM044
category: Idiom
type: idiom
topic: Feelings & Culture
learning_goal: Imparare a usare naturalmente “tug at the heartstrings” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART044
- GRAMART044
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
