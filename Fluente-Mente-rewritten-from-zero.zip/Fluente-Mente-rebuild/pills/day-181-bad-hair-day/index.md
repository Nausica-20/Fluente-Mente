---
layout: article
title: Bad hair day — una espressione da usare davvero
description: Imparare a usare naturalmente “bad hair day” nella situazione collegata.
content_id: PILL181
content_type: daily_pill
permalink: /pills/day-181-bad-hair-day/
canonical: /pills/day-181-bad-hair-day/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Bad hair day — una espressione da usare davvero
toc: true
level: B1+
day: 181
expression_id: EXP181
situation_id: SIT044
grammar_id: GRAM044
category: Idiom
type: idiom
topic: Daily Life & Feelings
learning_goal: Imparare a usare naturalmente “bad hair day” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART044
- GRAMART044
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
