---
layout: article
title: Willy-nilly — una espressione da usare davvero
description: Imparare a usare naturalmente “willy-nilly” nella situazione collegata.
content_id: PILL166
content_type: daily_pill
permalink: /pills/day-166-willy-nilly/
canonical: /pills/day-166-willy-nilly/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Willy-nilly — una espressione da usare davvero
toc: true
level: B2
day: 166
expression_id: EXP166
situation_id: SIT030
grammar_id: GRAM030
category: Colloquial English
type: adverb
topic: Choices & Actions
learning_goal: Imparare a usare naturalmente “willy-nilly” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART030
- GRAMART030
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
