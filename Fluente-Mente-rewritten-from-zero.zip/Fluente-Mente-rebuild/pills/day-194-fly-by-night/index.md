---
layout: article
title: Fly by night — una espressione da usare davvero
description: Imparare a usare naturalmente “fly by night” nella situazione collegata.
content_id: PILL194
content_type: daily_pill
permalink: /pills/day-194-fly-by-night/
canonical: /pills/day-194-fly-by-night/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Fly by night — una espressione da usare davvero
toc: true
level: B2
day: 194
expression_id: EXP194
situation_id: SIT033
grammar_id: GRAM033
category: Idiom
type: adjective
topic: Business & Trust
learning_goal: Imparare a usare naturalmente “fly by night” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART033
- GRAMART033
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
