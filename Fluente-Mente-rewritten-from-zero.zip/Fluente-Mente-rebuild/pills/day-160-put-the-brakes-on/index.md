---
layout: article
title: Put the brakes on — una espressione da usare davvero
description: Imparare a usare naturalmente “put the brakes on” nella situazione collegata.
content_id: PILL160
content_type: daily_pill
permalink: /pills/day-160-put-the-brakes-on/
canonical: /pills/day-160-put-the-brakes-on/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Put the brakes on — una espressione da usare davvero
toc: true
level: B1+
day: 160
expression_id: EXP160
situation_id: SIT009
grammar_id: GRAM009
category: Phrasal verb
type: verb phrase
topic: Change & Control
learning_goal: Imparare a usare naturalmente “put the brakes on” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART009
- GRAMART009
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
