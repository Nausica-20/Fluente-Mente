---
layout: article
title: Cook up an idea — una espressione da usare davvero
description: Imparare a usare naturalmente “cook up an idea” nella situazione collegata.
content_id: PILL131
content_type: daily_pill
permalink: /pills/day-131-cook-up-an-idea/
canonical: /pills/day-131-cook-up-an-idea/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Cook up an idea — una espressione da usare davvero
toc: true
level: B2
day: 131
expression_id: EXP131
situation_id: SIT008
grammar_id: GRAM008
category: Phrasal verb
type: phrasal verb
topic: Ideas & Planning
learning_goal: Imparare a usare naturalmente “cook up an idea” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART008
- GRAMART008
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
