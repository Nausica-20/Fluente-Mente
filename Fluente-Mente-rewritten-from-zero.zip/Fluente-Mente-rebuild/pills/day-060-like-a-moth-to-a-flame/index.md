---
layout: article
title: Like a moth to a flame — una espressione da usare davvero
description: Imparare a usare naturalmente “like a moth to a flame” nella situazione
  collegata.
content_id: PILL060
content_type: daily_pill
permalink: /pills/day-060-like-a-moth-to-a-flame/
canonical: /pills/day-060-like-a-moth-to-a-flame/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Like a moth to a flame — una espressione da usare davvero
toc: true
level: B2
day: 60
expression_id: EXP060
situation_id: SIT045
grammar_id: GRAM045
category: Idiom
type: idiom
topic: Attraction & Habits
learning_goal: Imparare a usare naturalmente “like a moth to a flame” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART045
- GRAMART045
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
