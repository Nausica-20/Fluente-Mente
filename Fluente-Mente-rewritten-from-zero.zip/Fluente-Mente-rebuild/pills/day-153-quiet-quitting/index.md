---
layout: article
title: Quiet quitting — una espressione da usare davvero
description: Imparare a usare naturalmente “quiet quitting” nella situazione collegata.
content_id: PILL153
content_type: daily_pill
permalink: /pills/day-153-quiet-quitting/
canonical: /pills/day-153-quiet-quitting/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Quiet quitting — una espressione da usare davvero
toc: true
level: B2
day: 153
expression_id: EXP153
situation_id: SIT049
grammar_id: GRAM049
category: Modern English
type: noun phrase
topic: Work
learning_goal: Imparare a usare naturalmente “quiet quitting” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART049
- GRAMART049
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
