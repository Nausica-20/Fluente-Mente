---
layout: article
title: A different kettle of fish — una espressione da usare davvero
description: Imparare a usare naturalmente “a different kettle of fish” nella situazione
  collegata.
content_id: PILL364
content_type: daily_pill
permalink: /pills/day-364-a-different-kettle-of-fish/
canonical: /pills/day-364-a-different-kettle-of-fish/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: A different kettle of fish — una espressione da usare davvero
toc: true
level: B2
day: 364
expression_id: EXP364
situation_id: SIT031
grammar_id: GRAM031
category: British English
type: noun phrase
topic: Comparison & Conversation
learning_goal: Imparare a usare naturalmente “a different kettle of fish” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART031
- GRAMART031
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
