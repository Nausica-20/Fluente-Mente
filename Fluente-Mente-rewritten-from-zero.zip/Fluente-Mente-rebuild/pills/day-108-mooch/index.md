---
layout: article
title: Mooch — una espressione da usare davvero
description: Imparare a usare naturalmente “mooch” nella situazione collegata.
content_id: PILL108
content_type: daily_pill
permalink: /pills/day-108-mooch/
canonical: /pills/day-108-mooch/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Mooch — una espressione da usare davvero
toc: true
level: B2
day: 108
expression_id: EXP108
situation_id: SIT014
grammar_id: GRAM014
category: British English
type: verb
topic: Daily Life
learning_goal: Imparare a usare naturalmente “mooch” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART014
- GRAMART014
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
