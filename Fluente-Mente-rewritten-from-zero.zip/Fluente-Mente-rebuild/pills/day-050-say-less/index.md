---
layout: article
title: Say less — una espressione da usare davvero
description: Imparare a usare naturalmente “say less” nella situazione collegata.
content_id: PILL050
content_type: daily_pill
permalink: /pills/day-050-say-less/
canonical: /pills/day-050-say-less/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Say less — una espressione da usare davvero
toc: true
level: B2
day: 50
expression_id: EXP050
situation_id: SIT047
grammar_id: GRAM047
category: Slang / Internet English
type: expression
topic: Reactions
learning_goal: Imparare a usare naturalmente “say less” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART047
- GRAMART047
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
