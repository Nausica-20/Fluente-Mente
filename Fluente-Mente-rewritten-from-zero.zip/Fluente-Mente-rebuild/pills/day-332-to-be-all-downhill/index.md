---
layout: article
title: To be all downhill — una espressione da usare davvero
description: Imparare a usare naturalmente “to be all downhill” nella situazione collegata.
content_id: PILL332
content_type: daily_pill
permalink: /pills/day-332-to-be-all-downhill/
canonical: /pills/day-332-to-be-all-downhill/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: To be all downhill — una espressione da usare davvero
toc: true
level: B2
day: 332
expression_id: EXP332
situation_id: SIT009
grammar_id: GRAM009
category: Idiom
type: idiom
topic: Difficulty & Change
learning_goal: Imparare a usare naturalmente “to be all downhill” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART009
- GRAMART009
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
