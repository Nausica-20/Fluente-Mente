---
layout: article
title: Hard at it — una espressione da usare davvero
description: Imparare a usare naturalmente “hard at it” nella situazione collegata.
content_id: PILL198
content_type: daily_pill
permalink: /pills/day-198-hard-at-it/
canonical: /pills/day-198-hard-at-it/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Hard at it — una espressione da usare davvero
toc: true
level: B1+
day: 198
expression_id: EXP198
situation_id: SIT050
grammar_id: GRAM050
category: Colloquial English
type: expression
topic: Work & Effort
learning_goal: Imparare a usare naturalmente “hard at it” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART050
- GRAMART050
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
