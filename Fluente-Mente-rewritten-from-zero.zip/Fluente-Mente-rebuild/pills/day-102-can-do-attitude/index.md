---
layout: article
title: Can-do attitude — una espressione da usare davvero
description: Imparare a usare naturalmente “can-do attitude” nella situazione collegata.
content_id: PILL102
content_type: daily_pill
permalink: /pills/day-102-can-do-attitude/
canonical: /pills/day-102-can-do-attitude/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Can-do attitude — una espressione da usare davvero
toc: true
level: B1
day: 102
expression_id: EXP102
situation_id: SIT005
grammar_id: GRAM005
category: Everyday expression
type: noun phrase
topic: Personal Development
learning_goal: Imparare a usare naturalmente “can-do attitude” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART005
- GRAMART005
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
