---
layout: article
title: Dial down — una espressione da usare davvero
description: Imparare a usare naturalmente “dial down” nella situazione collegata.
content_id: PILL206
content_type: daily_pill
permalink: /pills/day-206-dial-down/
canonical: /pills/day-206-dial-down/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Dial down — una espressione da usare davvero
toc: true
level: B1+
day: 206
expression_id: EXP206
situation_id: SIT009
grammar_id: GRAM009
category: Phrasal verb
type: phrasal verb
topic: Change & Control
learning_goal: Imparare a usare naturalmente “dial down” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART009
- GRAMART009
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
