---
layout: article
title: A big ask — una espressione da usare davvero
description: Imparare a usare naturalmente “a big ask” nella situazione collegata.
content_id: PILL039
content_type: daily_pill
permalink: /pills/day-039-a-big-ask/
canonical: /pills/day-039-a-big-ask/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: A big ask — una espressione da usare davvero
toc: true
level: B1+
day: 39
expression_id: EXP039
situation_id: SIT035
grammar_id: GRAM035
category: Colloquial English
type: noun phrase
topic: Requests
learning_goal: Imparare a usare naturalmente “a big ask” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART035
- GRAMART035
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
