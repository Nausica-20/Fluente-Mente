---
layout: article
title: Throw shade — una espressione da usare davvero
description: Imparare a usare naturalmente “throw shade” nella situazione collegata.
content_id: PILL286
content_type: daily_pill
permalink: /pills/day-286-throw-shade/
canonical: /pills/day-286-throw-shade/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Throw shade — una espressione da usare davvero
toc: true
level: B2
day: 286
expression_id: EXP286
situation_id: SIT002
grammar_id: GRAM002
category: Slang / Internet English
type: verb phrase
topic: Social English & Internet
learning_goal: Imparare a usare naturalmente “throw shade” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART002
- GRAMART002
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
