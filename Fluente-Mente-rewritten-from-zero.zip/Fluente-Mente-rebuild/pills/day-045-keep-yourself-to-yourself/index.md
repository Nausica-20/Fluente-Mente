---
layout: article
title: Keep yourself to yourself — una espressione da usare davvero
description: Imparare a usare naturalmente “keep yourself to yourself” nella situazione
  collegata.
content_id: PILL045
content_type: daily_pill
permalink: /pills/day-045-keep-yourself-to-yourself/
canonical: /pills/day-045-keep-yourself-to-yourself/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Keep yourself to yourself — una espressione da usare davvero
toc: true
level: B1+
day: 45
expression_id: EXP045
situation_id: SIT048
grammar_id: GRAM048
category: Colloquial English
type: expression
topic: Social Boundaries
learning_goal: Imparare a usare naturalmente “keep yourself to yourself” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART048
- GRAMART048
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
