---
layout: article
title: Talk shop — una espressione da usare davvero
description: Imparare a usare naturalmente “talk shop” nella situazione collegata.
content_id: PILL295
content_type: daily_pill
permalink: /pills/day-295-talk-shop/
canonical: /pills/day-295-talk-shop/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Talk shop — una espressione da usare davvero
toc: true
level: B2
day: 295
expression_id: EXP295
situation_id: SIT052
grammar_id: GRAM052
category: Everyday expression
type: idiom
topic: Work & Conversation
learning_goal: Imparare a usare naturalmente “talk shop” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART052
- GRAMART052
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
