---
layout: article
title: Roast — una espressione da usare davvero
description: Imparare a usare naturalmente “roast” nella situazione collegata.
content_id: PILL283
content_type: daily_pill
permalink: /pills/day-283-roast/
canonical: /pills/day-283-roast/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Roast — una espressione da usare davvero
toc: true
level: B1+
day: 283
expression_id: EXP283
situation_id: SIT048
grammar_id: GRAM048
category: Slang / Internet English
type: verb
topic: Humour & Social Media
learning_goal: Imparare a usare naturalmente “roast” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART048
- GRAMART048
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
