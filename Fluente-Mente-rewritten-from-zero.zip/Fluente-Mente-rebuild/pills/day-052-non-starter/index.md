---
layout: article
title: Non-starter — una espressione da usare davvero
description: Imparare a usare naturalmente “non-starter” nella situazione collegata.
content_id: PILL052
content_type: daily_pill
permalink: /pills/day-052-non-starter/
canonical: /pills/day-052-non-starter/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Non-starter — una espressione da usare davvero
toc: true
level: B1+
day: 52
expression_id: EXP052
situation_id: SIT017
grammar_id: GRAM017
category: Everyday expression
type: noun
topic: Decisions
learning_goal: Imparare a usare naturalmente “non-starter” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART017
- GRAMART017
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
