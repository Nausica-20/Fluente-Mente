---
layout: article
title: Friends in high places — una espressione da usare davvero
description: Imparare a usare naturalmente “friends in high places” nella situazione
  collegata.
content_id: PILL337
content_type: daily_pill
permalink: /pills/day-337-friends-in-high-places/
canonical: /pills/day-337-friends-in-high-places/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Friends in high places — una espressione da usare davvero
toc: true
level: B2
day: 337
expression_id: EXP337
situation_id: SIT051
grammar_id: GRAM051
category: Idiom
type: idiom
topic: Work & Connections
learning_goal: Imparare a usare naturalmente “friends in high places” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART051
- GRAMART051
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
