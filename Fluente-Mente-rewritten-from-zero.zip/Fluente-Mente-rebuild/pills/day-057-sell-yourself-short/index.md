---
layout: article
title: Sell yourself short — una espressione da usare davvero
description: Imparare a usare naturalmente “sell yourself short” nella situazione
  collegata.
content_id: PILL057
content_type: daily_pill
permalink: /pills/day-057-sell-yourself-short/
canonical: /pills/day-057-sell-yourself-short/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Sell yourself short — una espressione da usare davvero
toc: true
level: B1+
day: 57
expression_id: EXP057
situation_id: SIT003
grammar_id: GRAM003
category: Idiom
type: idiom
topic: Self-Confidence
learning_goal: Imparare a usare naturalmente “sell yourself short” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART003
- GRAMART003
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
