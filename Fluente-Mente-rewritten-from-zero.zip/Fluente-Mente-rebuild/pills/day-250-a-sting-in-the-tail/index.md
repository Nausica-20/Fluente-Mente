---
layout: article
title: A sting in the tail — una espressione da usare davvero
description: Imparare a usare naturalmente “a sting in the tail” nella situazione
  collegata.
content_id: PILL250
content_type: daily_pill
permalink: /pills/day-250-a-sting-in-the-tail/
canonical: /pills/day-250-a-sting-in-the-tail/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: A sting in the tail — una espressione da usare davvero
toc: true
level: B2
day: 250
expression_id: EXP250
situation_id: SIT023
grammar_id: GRAM023
category: Idiom
type: idiom
topic: Stories & Problems
learning_goal: Imparare a usare naturalmente “a sting in the tail” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART023
- GRAMART023
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
