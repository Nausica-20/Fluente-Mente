---
layout: article
title: Bug someone — una espressione da usare davvero
description: Imparare a usare naturalmente “bug someone” nella situazione collegata.
content_id: PILL165
content_type: daily_pill
permalink: /pills/day-165-bug-someone/
canonical: /pills/day-165-bug-someone/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Bug someone — una espressione da usare davvero
toc: true
level: B1+
day: 165
expression_id: EXP165
situation_id: SIT019
grammar_id: GRAM019
category: Phrasal verb
type: verb
topic: Annoyance & Relationships
learning_goal: Imparare a usare naturalmente “bug someone” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART019
- GRAMART019
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
