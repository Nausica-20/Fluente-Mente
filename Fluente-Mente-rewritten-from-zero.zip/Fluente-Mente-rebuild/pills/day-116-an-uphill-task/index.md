---
layout: article
title: An uphill task — una espressione da usare davvero
description: Imparare a usare naturalmente “an uphill task” nella situazione collegata.
content_id: PILL116
content_type: daily_pill
permalink: /pills/day-116-an-uphill-task/
canonical: /pills/day-116-an-uphill-task/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: An uphill task — una espressione da usare davvero
toc: true
level: B2
day: 116
expression_id: EXP116
situation_id: SIT033
grammar_id: GRAM033
category: Idiom
type: noun phrase
topic: Challenges
learning_goal: Imparare a usare naturalmente “an uphill task” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART033
- GRAMART033
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
