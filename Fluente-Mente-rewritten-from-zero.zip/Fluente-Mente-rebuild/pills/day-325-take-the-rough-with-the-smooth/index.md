---
layout: article
title: Take the rough with the smooth — una espressione da usare davvero
description: Imparare a usare naturalmente “take the rough with the smooth” nella
  situazione collegata.
content_id: PILL325
content_type: daily_pill
permalink: /pills/day-325-take-the-rough-with-the-smooth/
canonical: /pills/day-325-take-the-rough-with-the-smooth/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Take the rough with the smooth — una espressione da usare davvero
toc: true
level: B2
day: 325
expression_id: EXP325
situation_id: SIT009
grammar_id: GRAM009
category: Idiom
type: idiom
topic: Life & Change
learning_goal: Imparare a usare naturalmente “take the rough with the smooth” nella
  situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART009
- GRAMART009
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
