---
layout: article
title: Let the dust settle — una espressione da usare davvero
description: Imparare a usare naturalmente “let the dust settle” nella situazione
  collegata.
content_id: PILL338
content_type: daily_pill
permalink: /pills/day-338-let-the-dust-settle/
canonical: /pills/day-338-let-the-dust-settle/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Let the dust settle — una espressione da usare davvero
toc: true
level: B1+
day: 338
expression_id: EXP338
situation_id: SIT052
grammar_id: GRAM052
category: Idiom
type: idiom
topic: Problems & Decisions
learning_goal: Imparare a usare naturalmente “let the dust settle” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART052
- GRAMART052
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
