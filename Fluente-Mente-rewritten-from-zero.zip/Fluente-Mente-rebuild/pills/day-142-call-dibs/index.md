---
layout: article
title: Call dibs — una espressione da usare davvero
description: Imparare a usare naturalmente “call dibs” nella situazione collegata.
content_id: PILL142
content_type: daily_pill
permalink: /pills/day-142-call-dibs/
canonical: /pills/day-142-call-dibs/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Call dibs — una espressione da usare davvero
toc: true
level: B2
day: 142
expression_id: EXP142
situation_id: SIT001
grammar_id: GRAM001
category: Slang / Internet English
type: verb phrase
topic: Social English
learning_goal: Imparare a usare naturalmente “call dibs” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART001
- GRAMART001
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
