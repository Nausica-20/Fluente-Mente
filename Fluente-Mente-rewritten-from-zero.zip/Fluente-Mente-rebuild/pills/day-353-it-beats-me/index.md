---
layout: article
title: It beats me — una espressione da usare davvero
description: Imparare a usare naturalmente “it beats me” nella situazione collegata.
content_id: PILL353
content_type: daily_pill
permalink: /pills/day-353-it-beats-me/
canonical: /pills/day-353-it-beats-me/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: It beats me — una espressione da usare davvero
toc: true
level: B1+
day: 353
expression_id: EXP353
situation_id: SIT010
grammar_id: GRAM010
category: Colloquial English
type: expression
topic: Conversation & Confusion
learning_goal: Imparare a usare naturalmente “it beats me” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART010
- GRAMART010
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
