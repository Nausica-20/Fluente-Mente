---
layout: article
title: Take the wheel — una espressione da usare davvero
description: Imparare a usare naturalmente “take the wheel” nella situazione collegata.
content_id: PILL138
content_type: daily_pill
permalink: /pills/day-138-take-the-wheel/
canonical: /pills/day-138-take-the-wheel/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Take the wheel — una espressione da usare davvero
toc: true
level: B1+
day: 138
expression_id: EXP138
situation_id: SIT043
grammar_id: GRAM043
category: Idiom
type: idiom
topic: Responsibility & Control
learning_goal: Imparare a usare naturalmente “take the wheel” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART043
- GRAMART043
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
