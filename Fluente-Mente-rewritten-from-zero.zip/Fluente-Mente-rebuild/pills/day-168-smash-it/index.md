---
layout: article
title: Smash it — una espressione da usare davvero
description: Imparare a usare naturalmente “smash it” nella situazione collegata.
content_id: PILL168
content_type: daily_pill
permalink: /pills/day-168-smash-it/
canonical: /pills/day-168-smash-it/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Smash it — una espressione da usare davvero
toc: true
level: B1+
day: 168
expression_id: EXP168
situation_id: SIT039
grammar_id: GRAM039
category: Everyday expression
type: verb phrase
topic: Encouragement & Success
learning_goal: Imparare a usare naturalmente “smash it” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART039
- GRAMART039
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
