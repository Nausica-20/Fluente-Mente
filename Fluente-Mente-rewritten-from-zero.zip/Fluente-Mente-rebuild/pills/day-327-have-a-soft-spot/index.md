---
layout: article
title: Have a soft spot — una espressione da usare davvero
description: Imparare a usare naturalmente “have a soft spot” nella situazione collegata.
content_id: PILL327
content_type: daily_pill
permalink: /pills/day-327-have-a-soft-spot/
canonical: /pills/day-327-have-a-soft-spot/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Have a soft spot — una espressione da usare davvero
toc: true
level: B1+
day: 327
expression_id: EXP327
situation_id: SIT044
grammar_id: GRAM044
category: Idiom
type: idiom
topic: Feelings & Relationships
learning_goal: Imparare a usare naturalmente “have a soft spot” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART044
- GRAMART044
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
