---
layout: hub
title: La Pillola Inglese del Giorno
description: 365 micro-lezioni, una per giorno.
content_id: IDX-PILLS
content_type: pills_index
permalink: /pills/
canonical: /pills/
index: true
follow: true
sitemap: true
status: published
---

## La Pillola Inglese del Giorno

365 micro-lezioni, una per giorno.

<div class="card-grid">
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-001-go-to/">Go-to — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-002-read-the-room/">Read the room — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-003-tell-me-about-it/">Tell me about it — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-004-by-the-book/">By the book — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-005-do-the-trick/">Do the trick — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-006-from-the-get-go/">From the get-go — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-007-on-the-fly/">On the fly — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-008-find-your-groove/">Find your groove — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-009-top-notch/">Top-notch — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-010-off-the-cuff/">Off the cuff — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-011-take-the-plunge/">Take the plunge — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-012-second-nature/">Second nature — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-013-heavy-lifting/">Heavy lifting — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-014-stir-the-pot/">Stir the pot — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-015-let-loose/">Let loose — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-016-walk-someone-through/">Walk someone through — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-017-get-your-act-together/">Get your act together — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-018-hang-in-there/">Hang in there — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-019-bite-your-tongue/">Bite your tongue — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-020-off-the-top-of-my-head/">Off the top of my head — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-021-i-dont-buy-it/">I don't buy it — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-022-you-cant-go-wrong-with/">You can't go wrong with — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-023-the-flip-side/">The flip side — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-024-turn-over-a-new-leaf/">Turn over a new leaf — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">A2+</p><h3><a href="/pills/day-025-plan-b/">Plan b — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-026-a-little-something/">A little something — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-027-keep-someone-on-their-toes/">Keep someone on their toes — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-028-no-leg-to-stand-on/">No leg to stand on — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-029-cant-put-my-finger-on-it/">Can't put my finger on it — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-030-all-hands-on-deck/">All hands on deck — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-031-twist-someones-arm/">Twist someone's arm — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-032-speak-someones-language/">Speak someone's language — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-033-all-you-like/">All you like — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-034-around-the-clock/">Around the clock — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">A2+</p><h3><a href="/pills/day-035-on-the-go/">On the go — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-036-the-works/">The works — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">A2+</p><h3><a href="/pills/day-037-a-fresh-start/">A fresh start — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-038-moment-of-truth/">Moment of truth — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-039-a-big-ask/">A big ask — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-040-a-hunch/">A hunch — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-041-think-on-your-feet/">Think on your feet — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-042-short-change/">Short-change — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-043-cut-corners/">Cut corners — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-044-kick-the-can-down-the-road/">Kick the can down the road — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-045-keep-yourself-to-yourself/">Keep yourself to yourself — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-046-one-size-fits-all/">One size fits all — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-047-side-quest/">Side quest — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-048-understood-the-assignment/">Understood the assignment — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-049-hot-take/">Hot take — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-050-say-less/">Say less — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-051-try-it-on/">Try it on — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-052-non-starter/">Non-starter — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-053-no-notes/">No notes — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-054-share-your-life-story/">Share your life story — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-055-passing-ships/">Passing ships — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-056-onto-something/">Onto something — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-057-sell-yourself-short/">Sell yourself short — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-058-wrap-it-up/">Wrap it up — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-059-throw-ideas-at-the-wall/">Throw ideas at the wall — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-060-like-a-moth-to-a-flame/">Like a moth to a flame — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-061-gatekeep/">Gatekeep — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-062-in-over-my-head/">In over my head — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-063-yap/">Yap — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-064-flow-state/">Flow state — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-065-a-bit-of-a-stretch/">A bit of a stretch — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-066-go-through-a-rough-patch/">Go through a rough patch — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-067-learn-the-hard-way/">Learn the hard way — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-068-facepalm-moment/">Facepalm moment — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-069-shoot-off/">Shoot off — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-070-hot-on-the-heels-of/">Hot on the heels of — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-071-aura-farming/">Aura farming — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-072-lock-in/">Lock in — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-073-duck-out/">Duck out — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-074-off-base/">Off base — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-075-coded/">-coded — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-076-make-a-pigs-ear-of-something/">Make a pig's ear of something — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-077-core/">-core — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-078-cook/">Cook — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-079-neck-of-the-woods/">Neck of the woods — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-080-teething-problems/">Teething problems — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-081-muddle-along/">Muddle along — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-082-tough-it-out/">Tough it out — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-083-a-you-problem/">A you problem — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-084-the-ceo-of/">The ceo of — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-085-up-to-my-eyes-in/">Up to my eyes in — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-086-dabble-in/">Dabble in — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-087-rope-someone-in/">Rope someone in — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-088-scratch-the-surface/">Scratch the surface — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-089-step-into-someones-shoes/">Step into someone's shoes — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-090-drop/">Drop — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-091-touch-grass/">Touch grass — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-092-no-cap/">No cap — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-093-clap-back/">Clap back — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-094-on-point/">On point — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-095-kiss-something-goodbye/">Kiss something goodbye — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-096-jump-through-hoops/">Jump through hoops — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-097-call-it-a-day/">Call it a day — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">A2+</p><h3><a href="/pills/day-098-got-you/">Got you — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-099-know-the-score/">Know the score — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-100-steal-someones-thunder/">Steal someone's thunder — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-101-bring-something-to-the-party/">Bring something to the party — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-102-can-do-attitude/">Can-do attitude — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-103-skedaddle/">Skedaddle — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-104-fall-on-stony-ground/">Fall on stony ground — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-105-make-a-rod-for-your-own-back/">Make a rod for your own back — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-106-ship/">Ship — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-107-twig/">Twig — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-108-mooch/">Mooch — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-109-give-it-some-welly/">Give it some welly — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-110-shoehorn-something-in/">Shoehorn something in — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-111-thats-on-you/">That's on you — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-112-warts-and-all/">Warts and all — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-113-off-the-scale/">Off the scale — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-114-throw-ones-toys-out-the-pram/">Throw one's toys out the pram — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-115-make-my-skin-crawl/">Make my skin crawl — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-116-an-uphill-task/">An uphill task — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-117-bide-your-time/">Bide your time — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-118-stomping-ground/">Stomping ground — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-119-tug-at-the-heartstrings/">Tug at the heartstrings — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-120-clutch-at-straws/">Clutch at straws — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-121-crank-up/">Crank up — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-122-wishy-washy/">Wishy-washy — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-123-shook/">Shook — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-124-have-in-your-locker/">Have in your locker — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-125-zing/">Zing — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-126-beige-flag/">Beige flag — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-127-lay-it-on-thick/">Lay it on thick — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-128-telling-porkies/">Telling porkies — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-129-in-on-it/">In on it — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-130-brick-by-brick/">Brick by brick — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-131-cook-up-an-idea/">Cook up an idea — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-132-rinse-repeat/">Rinse, repeat — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-133-cash-in-on-something/">Cash in on something — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-134-make-your-hair-stand-on-end/">Make your hair stand on end — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-135-a-blow/">A blow — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-136-rear-its-head/">Rear its head — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-137-elbow-grease/">Elbow grease — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-138-take-the-wheel/">Take the wheel — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-139-dip-your-toe-into/">Dip your toe into — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-140-peaks-and-troughs/">Peaks and troughs — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-141-mental-gymnastics/">Mental gymnastics — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-142-call-dibs/">Call dibs — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-143-go-with-the-flow/">Go with the flow — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-144-drip-feed/">Drip-feed — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-145-scatterbrain/">Scatterbrain — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-146-be-in-with-a-shout/">Be in with a shout — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-147-hard-pass/">Hard pass — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-148-level-up/">Level up — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-149-shout-out/">Shout-out — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-150-it-escapes-me/">It escapes me — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-151-change-for-the-better/">Change for the better — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-152-the-gift-that-keeps-on-giving/">The gift that keeps on giving — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-153-quiet-quitting/">Quiet quitting — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-154-win-hands-down/">Win hands down — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-155-fever-pitch/">Fever pitch — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-156-twiddle-your-thumbs/">Twiddle your thumbs — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-157-dogs-dinner/">Dog's dinner — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-158-sitting-pretty/">Sitting pretty — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-159-feast-your-eyes/">Feast your eyes — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-160-put-the-brakes-on/">Put the brakes on — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-161-second-guess/">Second-guess — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-162-ins-and-outs/">Ins and outs — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-163-yes-and-no/">Yes and no — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-164-eat-your-words/">Eat your words — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-165-bug-someone/">Bug someone — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-166-willy-nilly/">Willy-nilly — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-167-gnarly/">Gnarly — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-168-smash-it/">Smash it — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-169-a-doddle/">A doddle — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-170-its-now-or-never/">It's now or never — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-171-happy-days/">Happy days — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-172-double-down/">Double down — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-173-game-face/">Game face — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-174-bitten-by-the-bug/">Bitten by the bug — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-175-onboarding/">Onboarding — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">C1</p><h3><a href="/pills/day-176-thereby-hangs-a-tale/">Thereby hangs a tale — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-177-the-royal-treatment/">The royal treatment — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-178-creatively-bankrupt/">Creatively bankrupt — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-179-as-if/">As if — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-180-ish/">Ish — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-181-bad-hair-day/">Bad hair day — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-182-promises-promises/">Promises, promises — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-183-not-see-hide-nor-hair/">Not see hide nor hair — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">C1</p><h3><a href="/pills/day-184-curates-egg/">Curate's egg — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-185-thatll-be-the-day/">That'll be the day — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-186-gathering-dust/">Gathering dust — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-187-easier-said-than-done/">Easier said than done — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-188-the-plot-thickens/">The plot thickens — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-189-all-at-sea/">All at sea — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-190-dont-mind-me/">Don't mind me — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-191-light-up-like-a-christmas-tree/">Light up like a christmas tree — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-192-im-out/">I'm out — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-193-sound-out/">Sound out — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-194-fly-by-night/">Fly by night — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-195-one-up/">One-up — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-196-tread-on-someones-toes/">Tread on someone's toes — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-197-run-for-the-hills/">Run for the hills — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-198-hard-at-it/">Hard at it — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-199-each-to-their-own/">Each to their own — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-200-fill-your-boots/">Fill your boots — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-201-in-my-travel-era/">In my travel era — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-202-come-full-circle/">Come full circle — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-203-grind-someones-gears/">Grind someone's gears — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-204-feel-seen/">Feel seen — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-205-its-giving/">It's giving — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-206-dial-down/">Dial down — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-207-the-name-of-the-game/">The name of the game — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-208-do-it-for-the-plot/">Do it for the plot — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-209-let-something-slide/">Let something slide — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-210-have-someone-on/">Have someone on — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-211-take-one-for-the-team/">Take one for the team — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-212-mind-your-ps-and-qs/">Mind your ps and qs — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-213-dad-dancing/">Dad dancing — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-214-big-data/">Big data — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-215-punch-above-your-weight/">Punch above your weight — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-216-social-media-influencer/">Social media influencer — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-217-goldilocks/">Goldilocks — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-218-ghosting/">Ghosting — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-219-slow-tv/">Slow tv — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-220-tiger-mother/">Tiger mother — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-221-digital-detox/">Digital detox — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-222-leave-a-bad-taste-in-your-mouth/">Leave a bad taste in your mouth — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-223-pea-souper/">Pea-souper — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-224-throw-in-the-towel/">Throw in the towel — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-225-a-walk-in-the-park/">A walk in the park — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-226-dumbphone/">Dumbphone — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-227-no-fear/">No fear — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-228-something-to-chew-on/">Something to chew on — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-229-waffle-on/">Waffle on — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-230-skew-whiff/">Skew-whiff — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-231-play-a-blinder/">Play a blinder — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-232-miffed/">Miffed — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-233-mardy/">Mardy — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-234-curry-favour/">Curry favour — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-235-take-the-biscuit/">Take the biscuit — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-236-step-on-it/">Step on it — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-237-ping/">Ping — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-238-crunch-time/">Crunch time — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-239-have-a-pop/">Have a pop — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-240-a-necessary-evil/">A necessary evil — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-241-all-that-jazz/">All that jazz — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-242-not-gonna-lie/">Not gonna lie — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-243-up-your-game/">Up your game — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-244-shout-it-from-the-rooftops/">Shout it from the rooftops — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-245-blow-the-cobwebs-away/">Blow the cobwebs away — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-246-a-knees-up/">A knees-up — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-247-put-someone-on-the-map/">Put someone on the map — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-248-down-in-the-dumps/">Down in the dumps — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">A2</p><h3><a href="/pills/day-249-excuse-me/">Excuse me — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-250-a-sting-in-the-tail/">A sting in the tail — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-251-cringe/">Cringe — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-252-its-the-for-me/">It's the … for me — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-253-down-up-for-something/">Down / up for something — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-254-lit/">Lit — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-255-vibe/">Vibe — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-256-noob/">Noob — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-257-adulting/">Adulting — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-258-slay/">Slay — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-259-push-back/">Push back — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-260-zip-it/">Zip it — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-261-botch-job/">Botch job — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-262-it-slaps/">It slaps — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-263-have-a-lot-of-plates-spinning/">Have a lot of plates spinning — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-264-pizzazz/">Pizzazz — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-265-oomph/">Oomph — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-266-snap-up/">Snap up — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-267-nothingburger/">Nothingburger — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-268-clout/">Clout — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-269-goat/">Goat — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-270-workation/">Workation — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-271-moonshot/">Moonshot — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-272-mic-drop/">Mic drop — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-273-tone-deaf/">Tone deaf — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-274-bring-your-a-game/">Bring your a game — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-275-you-do-you/">You do you — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-276-spoiler-alert/">Spoiler alert — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-277-doomscrolling/">Doomscrolling — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-278-crowdsourcing/">Crowdsourcing — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-279-one-step-at-a-time/">One step at a time — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-280-a-wake-up-call/">A wake-up call — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-281-thirsty/">Thirsty — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-282-vanilla/">Vanilla — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-283-roast/">Roast — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-284-sticking-point/">Sticking point — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-285-a-slippery-slope/">A slippery slope — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-286-throw-shade/">Throw shade — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-287-bite-the-bullet/">Bite the bullet — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-288-blended-working/">Blended working — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-289-jomo/">Jomo — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-290-spill-the-tea/">Spill the tea — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-291-flex/">Flex — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-292-salty/">Salty — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-293-running-on-fumes/">Running on fumes — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-294-left-on-read/">Left on read — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-295-talk-shop/">Talk shop — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-296-snackable/">Snackable — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-297-a-memory-like-a-sieve/">A memory like a sieve — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-298-peacocking/">Peacocking — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-299-rat-race/">Rat race — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-300-cabin-fever/">Cabin fever — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-301-buyers-remorse/">Buyer's remorse — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-302-carbon-footprint/">Carbon footprint — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-303-cough-up/">Cough up — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-304-brain-fade/">Brain fade — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-305-fib/">Fib — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-306-hot-under-the-collar/">Hot under the collar — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-307-fat-chance/">Fat chance — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-308-milk-it/">Milk it — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-309-cherry-pick/">Cherry-pick — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-310-fight-tooth-and-nail/">Fight tooth and nail — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-311-its-a-small-world/">It's a small world — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-312-vanish-into-thin-air/">Vanish into thin air — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-313-get-the-short-straw/">Get the short straw — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-314-soft-skills/">Soft skills — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-315-big-deal/">Big deal — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-316-clever-clogs/">Clever clogs — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-317-couch-surfing/">Couch surfing — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-318-like-riding-a-bike/">Like riding a bike — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-319-on-fire/">On fire — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-320-out-of-order/">Out of order — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-321-give-someone-the-runaround/">Give someone the runaround — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-322-laughing-all-the-way-to-the-bank/">Laughing all the way to the bank — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-323-keep-a-lid-on-it/">Keep a lid on it — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-324-pull-the-wool-over-someones-eyes/">Pull the wool over someone's eyes — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-325-take-the-rough-with-the-smooth/">Take the rough with the smooth — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-326-hard-nosed/">Hard-nosed — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-327-have-a-soft-spot/">Have a soft spot — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-328-make-a-song-and-dance-about-something/">Make a song and dance about something — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-329-a-shock-to-the-system/">A shock to the system — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">A2+</p><h3><a href="/pills/day-330-small-talk/">Small talk — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-331-a-bright-spark/">A bright spark — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-332-to-be-all-downhill/">To be all downhill — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-333-its-the-thought-that-counts/">It's the thought that counts — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-334-humblebrag/">Humblebrag — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-335-out-of-your-depth/">Out of your depth — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-336-if-the-cap-fits/">If the cap fits — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-337-friends-in-high-places/">Friends in high places — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-338-let-the-dust-settle/">Let the dust settle — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-339-nothing-to-shout-about/">Nothing to shout about — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-340-let-sleeping-dogs-lie/">Let sleeping dogs lie — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-341-bleed-someone-dry/">Bleed someone dry — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-342-an-old-hand/">An old hand — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-343-out-of-the-loop/">Out of the loop — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-344-rub-it-in/">Rub it in — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-345-barking-up-the-wrong-tree/">Barking up the wrong tree — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-346-a-taste-of-your-own-medicine/">A taste of your own medicine — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-347-the-best-of-both-worlds/">The best of both worlds — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-348-to-cut-a-long-story-short/">To cut a long story short — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-349-just-the-ticket/">Just the ticket — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-350-fomo/">Fomo — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1</p><h3><a href="/pills/day-351-have-a-go/">Have a go — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-352-wing-it/">Wing it — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-353-it-beats-me/">It beats me — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-354-give-us-a-bell/">Give us a bell — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-355-echo-chamber/">Echo chamber — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-356-the-heat-is-on/">The heat is on — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B1+</p><h3><a href="/pills/day-357-no-picnic/">No picnic — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-358-jack-of-all-trades/">Jack-of-all-trades — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-359-the-coast-is-clear/">The coast is clear — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-360-pull-a-fast-one/">Pull a fast one — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-361-to-cut-your-teeth/">To cut your teeth — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-362-shrinkflation/">Shrinkflation — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-363-la-la-land/">La-la land — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-364-a-different-kettle-of-fish/">A different kettle of fish — una espressione da usare davvero</a></h3></article>
<article class="content-card"><p class="eyebrow">B2</p><h3><a href="/pills/day-365-at-the-drop-of-a-hat/">At the drop of a hat — una espressione da usare davvero</a></h3></article>
</div>
