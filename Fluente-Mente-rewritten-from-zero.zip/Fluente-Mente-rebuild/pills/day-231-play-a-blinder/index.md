---
layout: article
title: Play a blinder — una espressione da usare davvero
description: Imparare a usare naturalmente “play a blinder” nella situazione collegata.
content_id: PILL231
content_type: daily_pill
permalink: /pills/day-231-play-a-blinder/
canonical: /pills/day-231-play-a-blinder/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Play a blinder — una espressione da usare davvero
toc: true
level: B2
day: 231
expression_id: EXP231
situation_id: SIT022
grammar_id: GRAM022
category: British English
type: idiom
topic: Performance & Sport
learning_goal: Imparare a usare naturalmente “play a blinder” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART022
- GRAMART022
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
