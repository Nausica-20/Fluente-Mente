---
layout: article
title: Punch above your weight — una espressione da usare davvero
description: Imparare a usare naturalmente “punch above your weight” nella situazione
  collegata.
content_id: PILL215
content_type: daily_pill
permalink: /pills/day-215-punch-above-your-weight/
canonical: /pills/day-215-punch-above-your-weight/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Punch above your weight — una espressione da usare davvero
toc: true
level: B2
day: 215
expression_id: EXP215
situation_id: SIT018
grammar_id: GRAM018
category: Idiom
type: idiom
topic: Performance & Competition
learning_goal: Imparare a usare naturalmente “punch above your weight” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART018
- GRAMART018
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
