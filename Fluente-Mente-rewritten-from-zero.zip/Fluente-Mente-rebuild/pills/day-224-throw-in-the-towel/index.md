---
layout: article
title: Throw in the towel — una espressione da usare davvero
description: Imparare a usare naturalmente “throw in the towel” nella situazione collegata.
content_id: PILL224
content_type: daily_pill
permalink: /pills/day-224-throw-in-the-towel/
canonical: /pills/day-224-throw-in-the-towel/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Throw in the towel — una espressione da usare davvero
toc: true
level: B1+
day: 224
expression_id: EXP224
situation_id: SIT025
grammar_id: GRAM025
category: Idiom
type: idiom
topic: Challenges & Failure
learning_goal: Imparare a usare naturalmente “throw in the towel” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART025
- GRAMART025
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
