---
layout: article
title: The name of the game — una espressione da usare davvero
description: Imparare a usare naturalmente “the name of the game” nella situazione
  collegata.
content_id: PILL207
content_type: daily_pill
permalink: /pills/day-207-the-name-of-the-game/
canonical: /pills/day-207-the-name-of-the-game/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: The name of the game — una espressione da usare davvero
toc: true
level: B2
day: 207
expression_id: EXP207
situation_id: SIT052
grammar_id: GRAM052
category: Idiom
type: idiom
topic: Work & Strategy
learning_goal: Imparare a usare naturalmente “the name of the game” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART052
- GRAMART052
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
