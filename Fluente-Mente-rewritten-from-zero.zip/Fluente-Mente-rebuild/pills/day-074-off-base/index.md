---
layout: article
title: Off base — una espressione da usare davvero
description: Imparare a usare naturalmente “off base” nella situazione collegata.
content_id: PILL074
content_type: daily_pill
permalink: /pills/day-074-off-base/
canonical: /pills/day-074-off-base/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Off base — una espressione da usare davvero
toc: true
level: B1+
day: 74
expression_id: EXP074
situation_id: SIT022
grammar_id: GRAM022
category: Colloquial English
type: adjective phrase
topic: Opinions & Reactions
learning_goal: Imparare a usare naturalmente “off base” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART022
- GRAMART022
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
