---
layout: article
title: Push back — una espressione da usare davvero
description: Imparare a usare naturalmente “push back” nella situazione collegata.
content_id: PILL259
content_type: daily_pill
permalink: /pills/day-259-push-back/
canonical: /pills/day-259-push-back/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Push back — una espressione da usare davvero
toc: true
level: B1+
day: 259
expression_id: EXP259
situation_id: SIT050
grammar_id: GRAM050
category: Phrasal verb
type: phrasal verb
topic: Work & Communication
learning_goal: Imparare a usare naturalmente “push back” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART050
- GRAMART050
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
