---
layout: article
title: Walk someone through — una espressione da usare davvero
description: Imparare a usare naturalmente “walk someone through” nella situazione
  collegata.
content_id: PILL016
content_type: daily_pill
permalink: /pills/day-016-walk-someone-through/
canonical: /pills/day-016-walk-someone-through/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Walk someone through — una espressione da usare davvero
toc: true
level: B1
day: 16
expression_id: EXP016
situation_id: SIT050
grammar_id: GRAM050
category: Everyday expression
type: phrasal_verb
topic: Explaining
learning_goal: Imparare a usare naturalmente “walk someone through” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART050
- GRAMART050
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
