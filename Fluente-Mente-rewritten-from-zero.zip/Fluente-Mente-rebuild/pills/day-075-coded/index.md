---
layout: article
title: -coded — una espressione da usare davvero
description: Imparare a usare naturalmente “-coded” nella situazione collegata.
content_id: PILL075
content_type: daily_pill
permalink: /pills/day-075-coded/
canonical: /pills/day-075-coded/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: -coded — una espressione da usare davvero
toc: true
level: B2
day: 75
expression_id: EXP075
situation_id: SIT048
grammar_id: GRAM048
category: New word / neologism
type: suffix
topic: Internet Culture
learning_goal: Imparare a usare naturalmente “-coded” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART048
- GRAMART048
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
