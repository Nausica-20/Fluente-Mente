---
layout: article
title: On the fly — una espressione da usare davvero
description: Imparare a usare naturalmente “on the fly” nella situazione collegata.
content_id: PILL007
content_type: daily_pill
permalink: /pills/day-007-on-the-fly/
canonical: /pills/day-007-on-the-fly/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: On the fly — una espressione da usare davvero
toc: true
level: B1
day: 7
expression_id: EXP007
situation_id: SIT036
grammar_id: GRAM036
category: Colloquial English
type: idiom
topic: Problem Solving
learning_goal: Imparare a usare naturalmente “on the fly” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART036
- GRAMART036
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
