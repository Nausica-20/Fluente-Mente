---
layout: article
title: Rat race — una espressione da usare davvero
description: Imparare a usare naturalmente “rat race” nella situazione collegata.
content_id: PILL299
content_type: daily_pill
permalink: /pills/day-299-rat-race/
canonical: /pills/day-299-rat-race/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Rat race — una espressione da usare davvero
toc: true
level: B2
day: 299
expression_id: EXP299
situation_id: SIT049
grammar_id: GRAM049
category: Idiom
type: noun phrase
topic: Work & Life
learning_goal: Imparare a usare naturalmente “rat race” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART049
- GRAMART049
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
