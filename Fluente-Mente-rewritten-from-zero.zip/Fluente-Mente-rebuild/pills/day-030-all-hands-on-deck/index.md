---
layout: article
title: All hands on deck — una espressione da usare davvero
description: Imparare a usare naturalmente “all hands on deck” nella situazione collegata.
content_id: PILL030
content_type: daily_pill
permalink: /pills/day-030-all-hands-on-deck/
canonical: /pills/day-030-all-hands-on-deck/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: All hands on deck — una espressione da usare davvero
toc: true
level: B1+
day: 30
expression_id: EXP030
situation_id: SIT052
grammar_id: GRAM052
category: Idiom
type: idiom
topic: Work & Teamwork
learning_goal: Imparare a usare naturalmente “all hands on deck” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART052
- GRAMART052
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
