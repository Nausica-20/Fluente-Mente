---
layout: article
title: Go through a rough patch — una espressione da usare davvero
description: Imparare a usare naturalmente “go through a rough patch” nella situazione
  collegata.
content_id: PILL066
content_type: daily_pill
permalink: /pills/day-066-go-through-a-rough-patch/
canonical: /pills/day-066-go-through-a-rough-patch/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Go through a rough patch — una espressione da usare davvero
toc: true
level: B1
day: 66
expression_id: EXP066
situation_id: SIT036
grammar_id: GRAM036
category: Everyday expression
type: expression
topic: Life & Problems
learning_goal: Imparare a usare naturalmente “go through a rough patch” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART036
- GRAMART036
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
