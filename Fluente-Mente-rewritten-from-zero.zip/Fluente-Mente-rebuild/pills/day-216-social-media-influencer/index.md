---
layout: article
title: Social media influencer — una espressione da usare davvero
description: Imparare a usare naturalmente “social media influencer” nella situazione
  collegata.
content_id: PILL216
content_type: daily_pill
permalink: /pills/day-216-social-media-influencer/
canonical: /pills/day-216-social-media-influencer/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Social media influencer — una espressione da usare davvero
toc: true
level: B1+
day: 216
expression_id: EXP216
situation_id: SIT048
grammar_id: GRAM048
category: Modern English
type: noun phrase
topic: Internet & Work
learning_goal: Imparare a usare naturalmente “social media influencer” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART048
- GRAMART048
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
