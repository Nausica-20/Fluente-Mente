---
layout: article
title: Know the score — una espressione da usare davvero
description: Imparare a usare naturalmente “know the score” nella situazione collegata.
content_id: PILL099
content_type: daily_pill
permalink: /pills/day-099-know-the-score/
canonical: /pills/day-099-know-the-score/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Know the score — una espressione da usare davvero
toc: true
level: B1+
day: 99
expression_id: EXP099
situation_id: SIT044
grammar_id: GRAM044
category: Idiom
type: idiom
topic: Understanding & Reality
learning_goal: Imparare a usare naturalmente “know the score” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART044
- GRAMART044
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
