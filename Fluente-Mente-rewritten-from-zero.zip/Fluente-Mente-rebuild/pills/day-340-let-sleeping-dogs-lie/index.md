---
layout: article
title: Let sleeping dogs lie — una espressione da usare davvero
description: Imparare a usare naturalmente “let sleeping dogs lie” nella situazione
  collegata.
content_id: PILL340
content_type: daily_pill
permalink: /pills/day-340-let-sleeping-dogs-lie/
canonical: /pills/day-340-let-sleeping-dogs-lie/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Let sleeping dogs lie — una espressione da usare davvero
toc: true
level: B2
day: 340
expression_id: EXP340
situation_id: SIT036
grammar_id: GRAM036
category: Idiom
type: idiom
topic: Problems & Relationships
learning_goal: Imparare a usare naturalmente “let sleeping dogs lie” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART036
- GRAMART036
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
