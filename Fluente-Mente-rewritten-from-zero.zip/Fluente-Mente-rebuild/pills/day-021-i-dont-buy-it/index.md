---
layout: article
title: I don't buy it — una espressione da usare davvero
description: Imparare a usare naturalmente “I don't buy it” nella situazione collegata.
content_id: PILL021
content_type: daily_pill
permalink: /pills/day-021-i-dont-buy-it/
canonical: /pills/day-021-i-dont-buy-it/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: I don't buy it — una espressione da usare davvero
toc: true
level: B1
day: 21
expression_id: EXP021
situation_id: SIT040
grammar_id: GRAM040
category: Colloquial English
type: expression
topic: Reactions
learning_goal: Imparare a usare naturalmente “I don't buy it” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART040
- GRAMART040
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
