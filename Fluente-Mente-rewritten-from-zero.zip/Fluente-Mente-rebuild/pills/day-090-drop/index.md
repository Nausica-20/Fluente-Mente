---
layout: article
title: Drop — una espressione da usare davvero
description: Imparare a usare naturalmente “drop” nella situazione collegata.
content_id: PILL090
content_type: daily_pill
permalink: /pills/day-090-drop/
canonical: /pills/day-090-drop/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Drop — una espressione da usare davvero
toc: true
level: B1+
day: 90
expression_id: EXP090
situation_id: SIT048
grammar_id: GRAM048
category: Modern English
type: verb
topic: Music & Media
learning_goal: Imparare a usare naturalmente “drop” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART048
- GRAMART048
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
