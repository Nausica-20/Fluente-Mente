---
layout: article
title: Elbow grease — una espressione da usare davvero
description: Imparare a usare naturalmente “elbow grease” nella situazione collegata.
content_id: PILL137
content_type: daily_pill
permalink: /pills/day-137-elbow-grease/
canonical: /pills/day-137-elbow-grease/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Elbow grease — una espressione da usare davvero
toc: true
level: B2
day: 137
expression_id: EXP137
situation_id: SIT049
grammar_id: GRAM049
category: Idiom
type: idiom
topic: Work & Chores
learning_goal: Imparare a usare naturalmente “elbow grease” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART049
- GRAMART049
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
