---
layout: article
title: Tell me about it — una espressione da usare davvero
description: Imparare a usare naturalmente “tell me about it” nella situazione collegata.
content_id: PILL003
content_type: daily_pill
permalink: /pills/day-003-tell-me-about-it/
canonical: /pills/day-003-tell-me-about-it/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Tell me about it — una espressione da usare davvero
toc: true
level: B1
day: 3
expression_id: EXP003
situation_id: SIT004
grammar_id: GRAM004
category: Everyday expression
type: expression
topic: Reactions
learning_goal: Imparare a usare naturalmente “tell me about it” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART004
- GRAMART004
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
