---
layout: article
title: Throw ideas at the wall — una espressione da usare davvero
description: Imparare a usare naturalmente “throw ideas at the wall” nella situazione
  collegata.
content_id: PILL059
content_type: daily_pill
permalink: /pills/day-059-throw-ideas-at-the-wall/
canonical: /pills/day-059-throw-ideas-at-the-wall/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Throw ideas at the wall — una espressione da usare davvero
toc: true
level: B2
day: 59
expression_id: EXP059
situation_id: SIT001
grammar_id: GRAM001
category: Colloquial English
type: expression
topic: Brainstorming
learning_goal: Imparare a usare naturalmente “throw ideas at the wall” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART001
- GRAMART001
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
