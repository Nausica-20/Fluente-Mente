---
layout: article
title: Don't mind me — una espressione da usare davvero
description: Imparare a usare naturalmente “don't mind me” nella situazione collegata.
content_id: PILL190
content_type: daily_pill
permalink: /pills/day-190-dont-mind-me/
canonical: /pills/day-190-dont-mind-me/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Don't mind me — una espressione da usare davvero
toc: true
level: B1
day: 190
expression_id: EXP190
situation_id: SIT002
grammar_id: GRAM002
category: Everyday expression
type: expression
topic: Social English
learning_goal: Imparare a usare naturalmente “don't mind me” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART002
- GRAMART002
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
