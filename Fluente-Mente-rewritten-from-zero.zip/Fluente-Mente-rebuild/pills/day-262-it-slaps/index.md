---
layout: article
title: It slaps — una espressione da usare davvero
description: Imparare a usare naturalmente “it slaps” nella situazione collegata.
content_id: PILL262
content_type: daily_pill
permalink: /pills/day-262-it-slaps/
canonical: /pills/day-262-it-slaps/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: It slaps — una espressione da usare davvero
toc: true
level: B2
day: 262
expression_id: EXP262
situation_id: SIT046
grammar_id: GRAM046
category: Slang / Internet English
type: expression
topic: Music & Culture
learning_goal: Imparare a usare naturalmente “it slaps” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART046
- GRAMART046
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
