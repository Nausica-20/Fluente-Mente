---
layout: article
title: No notes — una espressione da usare davvero
description: Imparare a usare naturalmente “no notes” nella situazione collegata.
content_id: PILL053
content_type: daily_pill
permalink: /pills/day-053-no-notes/
canonical: /pills/day-053-no-notes/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: No notes — una espressione da usare davvero
toc: true
level: B2
day: 53
expression_id: EXP053
situation_id: SIT048
grammar_id: GRAM048
category: Slang / Internet English
type: expression
topic: Praise & Reactions
learning_goal: Imparare a usare naturalmente “no notes” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART048
- GRAMART048
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
