---
layout: article
title: Carbon footprint — una espressione da usare davvero
description: Imparare a usare naturalmente “carbon footprint” nella situazione collegata.
content_id: PILL302
content_type: daily_pill
permalink: /pills/day-302-carbon-footprint/
canonical: /pills/day-302-carbon-footprint/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Carbon footprint — una espressione da usare davvero
toc: true
level: B1+
day: 302
expression_id: EXP302
situation_id: SIT031
grammar_id: GRAM031
category: Modern English
type: noun phrase
topic: Environment & Travel
learning_goal: Imparare a usare naturalmente “carbon footprint” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART031
- GRAMART031
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
