---
layout: article
title: Salty — una espressione da usare davvero
description: Imparare a usare naturalmente “salty” nella situazione collegata.
content_id: PILL292
content_type: daily_pill
permalink: /pills/day-292-salty/
canonical: /pills/day-292-salty/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Salty — una espressione da usare davvero
toc: true
level: B2
day: 292
expression_id: EXP292
situation_id: SIT044
grammar_id: GRAM044
category: Slang / Internet English
type: adjective
topic: Feelings & Reactions
learning_goal: Imparare a usare naturalmente “salty” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART044
- GRAMART044
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
