---
layout: article
title: A necessary evil — una espressione da usare davvero
description: Imparare a usare naturalmente “a necessary evil” nella situazione collegata.
content_id: PILL240
content_type: daily_pill
permalink: /pills/day-240-a-necessary-evil/
canonical: /pills/day-240-a-necessary-evil/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: A necessary evil — una espressione da usare davvero
toc: true
level: B2
day: 240
expression_id: EXP240
situation_id: SIT041
grammar_id: GRAM041
category: Idiom
type: noun phrase
topic: Choices & Life
learning_goal: Imparare a usare naturalmente “a necessary evil” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART041
- GRAMART041
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
