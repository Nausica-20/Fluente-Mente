---
layout: article
title: Make a rod for your own back — una espressione da usare davvero
description: Imparare a usare naturalmente “make a rod for your own back” nella situazione
  collegata.
content_id: PILL105
content_type: daily_pill
permalink: /pills/day-105-make-a-rod-for-your-own-back/
canonical: /pills/day-105-make-a-rod-for-your-own-back/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Make a rod for your own back — una espressione da usare davvero
toc: true
level: B2
day: 105
expression_id: EXP105
situation_id: SIT023
grammar_id: GRAM023
category: Idiom
type: idiom
topic: Problems & Choices
learning_goal: Imparare a usare naturalmente “make a rod for your own back” nella
  situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART023
- GRAMART023
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
