---
layout: article
title: Promises, promises — una espressione da usare davvero
description: Imparare a usare naturalmente “promises, promises” nella situazione collegata.
content_id: PILL182
content_type: daily_pill
permalink: /pills/day-182-promises-promises/
canonical: /pills/day-182-promises-promises/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Promises, promises — una espressione da usare davvero
toc: true
level: B2
day: 182
expression_id: EXP182
situation_id: SIT001
grammar_id: GRAM001
category: Colloquial English
type: expression
topic: Relationships & Trust
learning_goal: Imparare a usare naturalmente “promises, promises” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART001
- GRAMART001
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
