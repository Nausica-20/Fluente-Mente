---
layout: article
title: Kick the can down the road — una espressione da usare davvero
description: Imparare a usare naturalmente “kick the can down the road” nella situazione
  collegata.
content_id: PILL044
content_type: daily_pill
permalink: /pills/day-044-kick-the-can-down-the-road/
canonical: /pills/day-044-kick-the-can-down-the-road/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Kick the can down the road — una espressione da usare davvero
toc: true
level: B2
day: 44
expression_id: EXP044
situation_id: SIT052
grammar_id: GRAM052
category: Idiom
type: idiom
topic: Problem Solving
learning_goal: Imparare a usare naturalmente “kick the can down the road” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART052
- GRAMART052
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
