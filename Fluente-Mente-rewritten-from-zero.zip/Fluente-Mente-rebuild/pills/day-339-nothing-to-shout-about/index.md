---
layout: article
title: Nothing to shout about — una espressione da usare davvero
description: Imparare a usare naturalmente “nothing to shout about” nella situazione
  collegata.
content_id: PILL339
content_type: daily_pill
permalink: /pills/day-339-nothing-to-shout-about/
canonical: /pills/day-339-nothing-to-shout-about/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Nothing to shout about — una espressione da usare davvero
toc: true
level: B1+
day: 339
expression_id: EXP339
situation_id: SIT046
grammar_id: GRAM046
category: British English
type: expression
topic: Opinions & Reactions
learning_goal: Imparare a usare naturalmente “nothing to shout about” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART046
- GRAMART046
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
