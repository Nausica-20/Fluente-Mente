---
layout: article
title: Off the scale — una espressione da usare davvero
description: Imparare a usare naturalmente “off the scale” nella situazione collegata.
content_id: PILL113
content_type: daily_pill
permalink: /pills/day-113-off-the-scale/
canonical: /pills/day-113-off-the-scale/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Off the scale — una espressione da usare davvero
toc: true
level: B2
day: 113
expression_id: EXP113
situation_id: SIT003
grammar_id: GRAM003
category: Idiom
type: idiom
topic: Opinions & Intensity
learning_goal: Imparare a usare naturalmente “off the scale” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART003
- GRAMART003
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
