---
layout: article
title: Got you — una espressione da usare davvero
description: Imparare a usare naturalmente “got you” nella situazione collegata.
content_id: PILL098
content_type: daily_pill
permalink: /pills/day-098-got-you/
canonical: /pills/day-098-got-you/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Got you — una espressione da usare davvero
toc: true
level: A2+
day: 98
expression_id: EXP098
situation_id: SIT044
grammar_id: GRAM044
category: Everyday expression
type: expression
topic: Reactions & Support
learning_goal: Imparare a usare naturalmente “got you” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART044
- GRAMART044
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
