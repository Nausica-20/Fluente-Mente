---
layout: article
title: Mind your ps and qs — una espressione da usare davvero
description: Imparare a usare naturalmente “mind your Ps and Qs” nella situazione
  collegata.
content_id: PILL212
content_type: daily_pill
permalink: /pills/day-212-mind-your-ps-and-qs/
canonical: /pills/day-212-mind-your-ps-and-qs/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Mind your ps and qs — una espressione da usare davvero
toc: true
level: B2
day: 212
expression_id: EXP212
situation_id: SIT002
grammar_id: GRAM002
category: British English
type: idiom
topic: Politeness & Social English
learning_goal: Imparare a usare naturalmente “mind your Ps and Qs” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART002
- GRAMART002
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
