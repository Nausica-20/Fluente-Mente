---
layout: article
title: Run for the hills — una espressione da usare davvero
description: Imparare a usare naturalmente “run for the hills” nella situazione collegata.
content_id: PILL197
content_type: daily_pill
permalink: /pills/day-197-run-for-the-hills/
canonical: /pills/day-197-run-for-the-hills/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Run for the hills — una espressione da usare davvero
toc: true
level: B2
day: 197
expression_id: EXP197
situation_id: SIT023
grammar_id: GRAM023
category: Idiom
type: idiom
topic: Problems & Reactions
learning_goal: Imparare a usare naturalmente “run for the hills” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART023
- GRAMART023
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
