---
layout: article
title: Mic drop — una espressione da usare davvero
description: Imparare a usare naturalmente “mic drop” nella situazione collegata.
content_id: PILL272
content_type: daily_pill
permalink: /pills/day-272-mic-drop/
canonical: /pills/day-272-mic-drop/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Mic drop — una espressione da usare davvero
toc: true
level: B2
day: 272
expression_id: EXP272
situation_id: SIT010
grammar_id: GRAM010
category: Modern English
type: noun
topic: Conversation & Culture
learning_goal: Imparare a usare naturalmente “mic drop” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART010
- GRAMART010
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
