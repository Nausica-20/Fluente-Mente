---
layout: article
title: That'll be the day — una espressione da usare davvero
description: Imparare a usare naturalmente “that'll be the day” nella situazione collegata.
content_id: PILL185
content_type: daily_pill
permalink: /pills/day-185-thatll-be-the-day/
canonical: /pills/day-185-thatll-be-the-day/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: That'll be the day — una espressione da usare davvero
toc: true
level: B2
day: 185
expression_id: EXP185
situation_id: SIT017
grammar_id: GRAM017
category: Idiom
type: expression
topic: Reactions & Possibility
learning_goal: Imparare a usare naturalmente “that'll be the day” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART017
- GRAMART017
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
