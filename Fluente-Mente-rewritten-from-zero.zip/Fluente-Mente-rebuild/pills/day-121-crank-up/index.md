---
layout: article
title: Crank up — una espressione da usare davvero
description: Imparare a usare naturalmente “crank up” nella situazione collegata.
content_id: PILL121
content_type: daily_pill
permalink: /pills/day-121-crank-up/
canonical: /pills/day-121-crank-up/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Crank up — una espressione da usare davvero
toc: true
level: B1+
day: 121
expression_id: EXP121
situation_id: SIT009
grammar_id: GRAM009
category: Phrasal verb
type: phrasal verb
topic: Change & Intensity
learning_goal: Imparare a usare naturalmente “crank up” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART009
- GRAMART009
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
