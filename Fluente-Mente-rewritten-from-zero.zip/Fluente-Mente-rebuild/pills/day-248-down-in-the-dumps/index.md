---
layout: article
title: Down in the dumps — una espressione da usare davvero
description: Imparare a usare naturalmente “down in the dumps” nella situazione collegata.
content_id: PILL248
content_type: daily_pill
permalink: /pills/day-248-down-in-the-dumps/
canonical: /pills/day-248-down-in-the-dumps/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Down in the dumps — una espressione da usare davvero
toc: true
level: B2
day: 248
expression_id: EXP248
situation_id: SIT044
grammar_id: GRAM044
category: Idiom
type: idiom
topic: Feelings
learning_goal: Imparare a usare naturalmente “down in the dumps” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART044
- GRAMART044
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
