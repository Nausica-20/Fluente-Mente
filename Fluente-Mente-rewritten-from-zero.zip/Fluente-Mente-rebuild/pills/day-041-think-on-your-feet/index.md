---
layout: article
title: Think on your feet — una espressione da usare davvero
description: Imparare a usare naturalmente “think on your feet” nella situazione collegata.
content_id: PILL041
content_type: daily_pill
permalink: /pills/day-041-think-on-your-feet/
canonical: /pills/day-041-think-on-your-feet/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Think on your feet — una espressione da usare davvero
toc: true
level: B1+
day: 41
expression_id: EXP041
situation_id: SIT036
grammar_id: GRAM036
category: Idiom
type: idiom
topic: Problem Solving
learning_goal: Imparare a usare naturalmente “think on your feet” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART036
- GRAMART036
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
