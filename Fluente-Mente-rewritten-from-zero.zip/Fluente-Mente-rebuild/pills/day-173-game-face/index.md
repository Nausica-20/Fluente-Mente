---
layout: article
title: Game face — una espressione da usare davvero
description: Imparare a usare naturalmente “game face” nella situazione collegata.
content_id: PILL173
content_type: daily_pill
permalink: /pills/day-173-game-face/
canonical: /pills/day-173-game-face/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Game face — una espressione da usare davvero
toc: true
level: B2
day: 173
expression_id: EXP173
situation_id: SIT027
grammar_id: GRAM027
category: Colloquial English
type: noun phrase
topic: Performance & Determination
learning_goal: Imparare a usare naturalmente “game face” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART027
- GRAMART027
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
