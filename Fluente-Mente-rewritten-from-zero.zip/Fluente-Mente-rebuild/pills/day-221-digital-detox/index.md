---
layout: article
title: Digital detox — una espressione da usare davvero
description: Imparare a usare naturalmente “digital detox” nella situazione collegata.
content_id: PILL221
content_type: daily_pill
permalink: /pills/day-221-digital-detox/
canonical: /pills/day-221-digital-detox/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Digital detox — una espressione da usare davvero
toc: true
level: B1+
day: 221
expression_id: EXP221
situation_id: SIT002
grammar_id: GRAM002
category: Modern English
type: noun phrase
topic: Technology & Life
learning_goal: Imparare a usare naturalmente “digital detox” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART002
- GRAMART002
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
