---
layout: article
title: Excuse me — una espressione da usare davvero
description: Imparare a usare naturalmente “excuse me” nella situazione collegata.
content_id: PILL249
content_type: daily_pill
permalink: /pills/day-249-excuse-me/
canonical: /pills/day-249-excuse-me/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Excuse me — una espressione da usare davvero
toc: true
level: A2
day: 249
expression_id: EXP249
situation_id: SIT010
grammar_id: GRAM010
category: Everyday expression
type: expression
topic: Everyday Conversation
learning_goal: Imparare a usare naturalmente “excuse me” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART010
- GRAMART010
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
