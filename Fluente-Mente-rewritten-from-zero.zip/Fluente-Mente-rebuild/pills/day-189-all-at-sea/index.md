---
layout: article
title: All at sea — una espressione da usare davvero
description: Imparare a usare naturalmente “all at sea” nella situazione collegata.
content_id: PILL189
content_type: daily_pill
permalink: /pills/day-189-all-at-sea/
canonical: /pills/day-189-all-at-sea/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: All at sea — una espressione da usare davvero
toc: true
level: B2
day: 189
expression_id: EXP189
situation_id: SIT036
grammar_id: GRAM036
category: Idiom
type: idiom
topic: Confusion & Problems
learning_goal: Imparare a usare naturalmente “all at sea” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART036
- GRAMART036
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
