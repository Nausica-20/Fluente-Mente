---
layout: article
title: Dumbphone — una espressione da usare davvero
description: Imparare a usare naturalmente “dumbphone” nella situazione collegata.
content_id: PILL226
content_type: daily_pill
permalink: /pills/day-226-dumbphone/
canonical: /pills/day-226-dumbphone/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Dumbphone — una espressione da usare davvero
toc: true
level: B2
day: 226
expression_id: EXP226
situation_id: SIT031
grammar_id: GRAM031
category: New word / neologism
type: noun
topic: Technology & Lifestyle
learning_goal: Imparare a usare naturalmente “dumbphone” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART031
- GRAMART031
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
