---
layout: article
title: Understood the assignment — una espressione da usare davvero
description: Imparare a usare naturalmente “understood the assignment” nella situazione
  collegata.
content_id: PILL048
content_type: daily_pill
permalink: /pills/day-048-understood-the-assignment/
canonical: /pills/day-048-understood-the-assignment/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Understood the assignment — una espressione da usare davvero
toc: true
level: B2
day: 48
expression_id: EXP048
situation_id: SIT051
grammar_id: GRAM051
category: Slang / Internet English
type: expression
topic: Internet Culture
learning_goal: Imparare a usare naturalmente “understood the assignment” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART051
- GRAMART051
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
