---
layout: article
title: Ghosting — una espressione da usare davvero
description: Imparare a usare naturalmente “ghosting” nella situazione collegata.
content_id: PILL218
content_type: daily_pill
permalink: /pills/day-218-ghosting/
canonical: /pills/day-218-ghosting/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Ghosting — una espressione da usare davvero
toc: true
level: B2
day: 218
expression_id: EXP218
situation_id: SIT047
grammar_id: GRAM047
category: Modern English
type: noun
topic: Relationships & Internet
learning_goal: Imparare a usare naturalmente “ghosting” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART047
- GRAMART047
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
