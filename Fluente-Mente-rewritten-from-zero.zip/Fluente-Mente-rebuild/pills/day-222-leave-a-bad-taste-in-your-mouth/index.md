---
layout: article
title: Leave a bad taste in your mouth — una espressione da usare davvero
description: Imparare a usare naturalmente “leave a bad taste in your mouth” nella
  situazione collegata.
content_id: PILL222
content_type: daily_pill
permalink: /pills/day-222-leave-a-bad-taste-in-your-mouth/
canonical: /pills/day-222-leave-a-bad-taste-in-your-mouth/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Leave a bad taste in your mouth — una espressione da usare davvero
toc: true
level: B2
day: 222
expression_id: EXP222
situation_id: SIT044
grammar_id: GRAM044
category: Idiom
type: idiom
topic: Feelings & Opinions
learning_goal: Imparare a usare naturalmente “leave a bad taste in your mouth” nella
  situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART044
- GRAMART044
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
