---
layout: article
title: On the go — una espressione da usare davvero
description: Imparare a usare naturalmente “on the go” nella situazione collegata.
content_id: PILL035
content_type: daily_pill
permalink: /pills/day-035-on-the-go/
canonical: /pills/day-035-on-the-go/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: On the go — una espressione da usare davvero
toc: true
level: A2+
day: 35
expression_id: EXP035
situation_id: SIT042
grammar_id: GRAM042
category: Everyday expression
type: expression
topic: Daily Life
learning_goal: Imparare a usare naturalmente “on the go” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART042
- GRAMART042
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
