---
layout: article
title: Spill the tea — una espressione da usare davvero
description: Imparare a usare naturalmente “spill the tea” nella situazione collegata.
content_id: PILL290
content_type: daily_pill
permalink: /pills/day-290-spill-the-tea/
canonical: /pills/day-290-spill-the-tea/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Spill the tea — una espressione da usare davvero
toc: true
level: B2
day: 290
expression_id: EXP290
situation_id: SIT048
grammar_id: GRAM048
category: Slang / Internet English
type: expression
topic: Social Media & Conversation
learning_goal: Imparare a usare naturalmente “spill the tea” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART048
- GRAMART048
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
