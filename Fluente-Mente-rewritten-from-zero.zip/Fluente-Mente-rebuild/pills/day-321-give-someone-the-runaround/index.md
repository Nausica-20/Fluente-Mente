---
layout: article
title: Give someone the runaround — una espressione da usare davvero
description: Imparare a usare naturalmente “give someone the runaround” nella situazione
  collegata.
content_id: PILL321
content_type: daily_pill
permalink: /pills/day-321-give-someone-the-runaround/
canonical: /pills/day-321-give-someone-the-runaround/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Give someone the runaround — una espressione da usare davvero
toc: true
level: B2
day: 321
expression_id: EXP321
situation_id: SIT037
grammar_id: GRAM037
category: Idiom
type: idiom
topic: Customer Service & Problems
learning_goal: Imparare a usare naturalmente “give someone the runaround” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART037
- GRAMART037
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
