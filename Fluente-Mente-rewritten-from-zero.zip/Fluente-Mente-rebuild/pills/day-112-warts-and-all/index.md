---
layout: article
title: Warts and all — una espressione da usare davvero
description: Imparare a usare naturalmente “warts and all” nella situazione collegata.
content_id: PILL112
content_type: daily_pill
permalink: /pills/day-112-warts-and-all/
canonical: /pills/day-112-warts-and-all/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Warts and all — una espressione da usare davvero
toc: true
level: B2
day: 112
expression_id: EXP112
situation_id: SIT047
grammar_id: GRAM047
category: Idiom
type: idiom
topic: Honesty & Description
learning_goal: Imparare a usare naturalmente “warts and all” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART047
- GRAMART047
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
