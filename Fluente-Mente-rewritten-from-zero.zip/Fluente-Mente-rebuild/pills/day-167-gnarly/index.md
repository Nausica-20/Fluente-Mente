---
layout: article
title: Gnarly — una espressione da usare davvero
description: Imparare a usare naturalmente “gnarly” nella situazione collegata.
content_id: PILL167
content_type: daily_pill
permalink: /pills/day-167-gnarly/
canonical: /pills/day-167-gnarly/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Gnarly — una espressione da usare davvero
toc: true
level: B2
day: 167
expression_id: EXP167
situation_id: SIT022
grammar_id: GRAM022
category: Colloquial English
type: adjective
topic: Description & Reactions
learning_goal: Imparare a usare naturalmente “gnarly” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART022
- GRAMART022
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
