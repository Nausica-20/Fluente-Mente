---
layout: article
title: Slay — una espressione da usare davvero
description: Imparare a usare naturalmente “slay” nella situazione collegata.
content_id: PILL258
content_type: daily_pill
permalink: /pills/day-258-slay/
canonical: /pills/day-258-slay/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Slay — una espressione da usare davvero
toc: true
level: B2
day: 258
expression_id: EXP258
situation_id: SIT032
grammar_id: GRAM032
category: Slang / Internet English
type: verb
topic: Praise & Culture
learning_goal: Imparare a usare naturalmente “slay” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART032
- GRAMART032
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
