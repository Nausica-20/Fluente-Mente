---
layout: article
title: Cut corners — una espressione da usare davvero
description: Imparare a usare naturalmente “cut corners” nella situazione collegata.
content_id: PILL043
content_type: daily_pill
permalink: /pills/day-043-cut-corners/
canonical: /pills/day-043-cut-corners/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Cut corners — una espressione da usare davvero
toc: true
level: B1
day: 43
expression_id: EXP043
situation_id: SIT052
grammar_id: GRAM052
category: Idiom
type: idiom
topic: Work & Quality
learning_goal: Imparare a usare naturalmente “cut corners” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART052
- GRAMART052
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
