---
layout: article
title: Blow the cobwebs away — una espressione da usare davvero
description: Imparare a usare naturalmente “blow the cobwebs away” nella situazione
  collegata.
content_id: PILL245
content_type: daily_pill
permalink: /pills/day-245-blow-the-cobwebs-away/
canonical: /pills/day-245-blow-the-cobwebs-away/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Blow the cobwebs away — una espressione da usare davvero
toc: true
level: B2
day: 245
expression_id: EXP245
situation_id: SIT031
grammar_id: GRAM031
category: British English
type: idiom
topic: Energy & Wellbeing
learning_goal: Imparare a usare naturalmente “blow the cobwebs away” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART031
- GRAMART031
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
