---
layout: article
title: Drip-feed — una espressione da usare davvero
description: Imparare a usare naturalmente “drip-feed” nella situazione collegata.
content_id: PILL144
content_type: daily_pill
permalink: /pills/day-144-drip-feed/
canonical: /pills/day-144-drip-feed/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Drip-feed — una espressione da usare davvero
toc: true
level: B2
day: 144
expression_id: EXP144
situation_id: SIT047
grammar_id: GRAM047
category: Phrasal verb
type: verb
topic: Communication & Media
learning_goal: Imparare a usare naturalmente “drip-feed” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART047
- GRAMART047
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
