---
layout: article
title: Get the short straw — una espressione da usare davvero
description: Imparare a usare naturalmente “get the short straw” nella situazione
  collegata.
content_id: PILL313
content_type: daily_pill
permalink: /pills/day-313-get-the-short-straw/
canonical: /pills/day-313-get-the-short-straw/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Get the short straw — una espressione da usare davvero
toc: true
level: B2
day: 313
expression_id: EXP313
situation_id: SIT025
grammar_id: GRAM025
category: Idiom
type: idiom
topic: Fairness & Situations
learning_goal: Imparare a usare naturalmente “get the short straw” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART025
- GRAMART025
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
