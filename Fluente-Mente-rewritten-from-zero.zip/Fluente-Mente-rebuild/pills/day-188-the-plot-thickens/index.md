---
layout: article
title: The plot thickens — una espressione da usare davvero
description: Imparare a usare naturalmente “the plot thickens” nella situazione collegata.
content_id: PILL188
content_type: daily_pill
permalink: /pills/day-188-the-plot-thickens/
canonical: /pills/day-188-the-plot-thickens/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: The plot thickens — una espressione da usare davvero
toc: true
level: B2
day: 188
expression_id: EXP188
situation_id: SIT032
grammar_id: GRAM032
category: Idiom
type: idiom
topic: Stories & Problems
learning_goal: Imparare a usare naturalmente “the plot thickens” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART032
- GRAMART032
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
