---
layout: article
title: Step on it — una espressione da usare davvero
description: Imparare a usare naturalmente “step on it” nella situazione collegata.
content_id: PILL236
content_type: daily_pill
permalink: /pills/day-236-step-on-it/
canonical: /pills/day-236-step-on-it/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Step on it — una espressione da usare davvero
toc: true
level: B1+
day: 236
expression_id: EXP236
situation_id: SIT022
grammar_id: GRAM022
category: Idiom
type: idiom
topic: Time & Movement
learning_goal: Imparare a usare naturalmente “step on it” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART022
- GRAMART022
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
