---
layout: article
title: Eat your words — una espressione da usare davvero
description: Imparare a usare naturalmente “eat your words” nella situazione collegata.
content_id: PILL164
content_type: daily_pill
permalink: /pills/day-164-eat-your-words/
canonical: /pills/day-164-eat-your-words/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Eat your words — una espressione da usare davvero
toc: true
level: B2
day: 164
expression_id: EXP164
situation_id: SIT049
grammar_id: GRAM049
category: Idiom
type: idiom
topic: Mistakes & Opinions
learning_goal: Imparare a usare naturalmente “eat your words” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART049
- GRAMART049
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
