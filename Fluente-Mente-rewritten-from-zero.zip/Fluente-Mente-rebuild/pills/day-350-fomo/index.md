---
layout: article
title: Fomo — una espressione da usare davvero
description: Imparare a usare naturalmente “FOMO” nella situazione collegata.
content_id: PILL350
content_type: daily_pill
permalink: /pills/day-350-fomo/
canonical: /pills/day-350-fomo/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Fomo — una espressione da usare davvero
toc: true
level: B2
day: 350
expression_id: EXP350
situation_id: SIT048
grammar_id: GRAM048
category: Slang / Internet English
type: noun/acronym
topic: Social Media & Feelings
learning_goal: Imparare a usare naturalmente “FOMO” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART048
- GRAMART048
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
