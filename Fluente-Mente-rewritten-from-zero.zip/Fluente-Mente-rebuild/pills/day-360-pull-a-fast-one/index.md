---
layout: article
title: Pull a fast one — una espressione da usare davvero
description: Imparare a usare naturalmente “pull a fast one” nella situazione collegata.
content_id: PILL360
content_type: daily_pill
permalink: /pills/day-360-pull-a-fast-one/
canonical: /pills/day-360-pull-a-fast-one/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Pull a fast one — una espressione da usare davvero
toc: true
level: B2
day: 360
expression_id: EXP360
situation_id: SIT019
grammar_id: GRAM019
category: Idiom
type: idiom
topic: Deception
learning_goal: Imparare a usare naturalmente “pull a fast one” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART019
- GRAMART019
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
