---
layout: article
title: The works — una espressione da usare davvero
description: Imparare a usare naturalmente “the works” nella situazione collegata.
content_id: PILL036
content_type: daily_pill
permalink: /pills/day-036-the-works/
canonical: /pills/day-036-the-works/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: The works — una espressione da usare davvero
toc: true
level: B1
day: 36
expression_id: EXP036
situation_id: SIT012
grammar_id: GRAM012
category: Everyday expression
type: noun phrase
topic: Food & Services
learning_goal: Imparare a usare naturalmente “the works” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART012
- GRAMART012
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
