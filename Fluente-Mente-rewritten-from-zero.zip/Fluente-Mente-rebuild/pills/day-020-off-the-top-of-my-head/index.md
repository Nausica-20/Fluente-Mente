---
layout: article
title: Off the top of my head — una espressione da usare davvero
description: Imparare a usare naturalmente “off the top of my head” nella situazione
  collegata.
content_id: PILL020
content_type: daily_pill
permalink: /pills/day-020-off-the-top-of-my-head/
canonical: /pills/day-020-off-the-top-of-my-head/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Off the top of my head — una espressione da usare davvero
toc: true
level: B1
day: 20
expression_id: EXP020
situation_id: SIT050
grammar_id: GRAM050
category: Everyday expression
type: expression
topic: Speaking
learning_goal: Imparare a usare naturalmente “off the top of my head” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART050
- GRAMART050
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
