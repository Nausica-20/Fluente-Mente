---
layout: article
title: All that jazz — una espressione da usare davvero
description: Imparare a usare naturalmente “all that jazz” nella situazione collegata.
content_id: PILL241
content_type: daily_pill
permalink: /pills/day-241-all-that-jazz/
canonical: /pills/day-241-all-that-jazz/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: All that jazz — una espressione da usare davvero
toc: true
level: B2
day: 241
expression_id: EXP241
situation_id: SIT010
grammar_id: GRAM010
category: Colloquial English
type: idiom
topic: Conversation
learning_goal: Imparare a usare naturalmente “all that jazz” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART010
- GRAMART010
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
