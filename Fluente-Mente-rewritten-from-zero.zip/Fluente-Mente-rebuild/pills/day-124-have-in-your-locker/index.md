---
layout: article
title: Have in your locker — una espressione da usare davvero
description: Imparare a usare naturalmente “have in your locker” nella situazione
  collegata.
content_id: PILL124
content_type: daily_pill
permalink: /pills/day-124-have-in-your-locker/
canonical: /pills/day-124-have-in-your-locker/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Have in your locker — una espressione da usare davvero
toc: true
level: B2
day: 124
expression_id: EXP124
situation_id: SIT027
grammar_id: GRAM027
category: British English
type: expression
topic: Skills & Strengths
learning_goal: Imparare a usare naturalmente “have in your locker” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART027
- GRAMART027
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
