---
layout: article
title: Get your act together — una espressione da usare davvero
description: Imparare a usare naturalmente “get your act together” nella situazione
  collegata.
content_id: PILL017
content_type: daily_pill
permalink: /pills/day-017-get-your-act-together/
canonical: /pills/day-017-get-your-act-together/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Get your act together — una espressione da usare davvero
toc: true
level: B1
day: 17
expression_id: EXP017
situation_id: SIT052
grammar_id: GRAM052
category: Colloquial English
type: idiom
topic: Organization
learning_goal: Imparare a usare naturalmente “get your act together” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART052
- GRAMART052
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
