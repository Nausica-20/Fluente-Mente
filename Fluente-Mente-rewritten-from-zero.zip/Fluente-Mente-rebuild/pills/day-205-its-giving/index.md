---
layout: article
title: It's giving — una espressione da usare davvero
description: Imparare a usare naturalmente “it's giving” nella situazione collegata.
content_id: PILL205
content_type: daily_pill
permalink: /pills/day-205-its-giving/
canonical: /pills/day-205-its-giving/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: It's giving — una espressione da usare davvero
toc: true
level: B2
day: 205
expression_id: EXP205
situation_id: SIT048
grammar_id: GRAM048
category: Slang / Internet English
type: expression
topic: Internet & Culture
learning_goal: Imparare a usare naturalmente “it's giving” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART048
- GRAMART048
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
