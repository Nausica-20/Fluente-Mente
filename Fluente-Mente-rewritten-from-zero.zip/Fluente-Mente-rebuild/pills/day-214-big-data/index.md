---
layout: article
title: Big data — una espressione da usare davvero
description: Imparare a usare naturalmente “big data” nella situazione collegata.
content_id: PILL214
content_type: daily_pill
permalink: /pills/day-214-big-data/
canonical: /pills/day-214-big-data/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Big data — una espressione da usare davvero
toc: true
level: B2
day: 214
expression_id: EXP214
situation_id: SIT049
grammar_id: GRAM049
category: Modern English
type: noun phrase
topic: Technology & Work
learning_goal: Imparare a usare naturalmente “big data” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART049
- GRAMART049
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
