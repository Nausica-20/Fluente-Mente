---
layout: article
title: Tone deaf — una espressione da usare davvero
description: Imparare a usare naturalmente “tone deaf” nella situazione collegata.
content_id: PILL273
content_type: daily_pill
permalink: /pills/day-273-tone-deaf/
canonical: /pills/day-273-tone-deaf/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Tone deaf — una espressione da usare davvero
toc: true
level: B2
day: 273
expression_id: EXP273
situation_id: SIT008
grammar_id: GRAM008
category: Colloquial English
type: adjective
topic: Social English
learning_goal: Imparare a usare naturalmente “tone deaf” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART008
- GRAMART008
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
