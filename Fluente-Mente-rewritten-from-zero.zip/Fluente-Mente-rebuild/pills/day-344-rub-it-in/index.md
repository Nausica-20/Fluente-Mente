---
layout: article
title: Rub it in — una espressione da usare davvero
description: Imparare a usare naturalmente “rub it in” nella situazione collegata.
content_id: PILL344
content_type: daily_pill
permalink: /pills/day-344-rub-it-in/
canonical: /pills/day-344-rub-it-in/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Rub it in — una espressione da usare davvero
toc: true
level: B1+
day: 344
expression_id: EXP344
situation_id: SIT040
grammar_id: GRAM040
category: Phrasal verb
type: phrasal verb
topic: Relationships & Reactions
learning_goal: Imparare a usare naturalmente “rub it in” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART040
- GRAMART040
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
