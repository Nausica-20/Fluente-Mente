---
layout: article
title: Let something slide — una espressione da usare davvero
description: Imparare a usare naturalmente “let something slide” nella situazione
  collegata.
content_id: PILL209
content_type: daily_pill
permalink: /pills/day-209-let-something-slide/
canonical: /pills/day-209-let-something-slide/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Let something slide — una espressione da usare davvero
toc: true
level: B1+
day: 209
expression_id: EXP209
situation_id: SIT002
grammar_id: GRAM002
category: Phrasal verb
type: phrasal verb
topic: Social English
learning_goal: Imparare a usare naturalmente “let something slide” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART002
- GRAMART002
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
