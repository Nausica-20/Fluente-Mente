---
layout: article
title: The gift that keeps on giving — una espressione da usare davvero
description: Imparare a usare naturalmente “the gift that keeps on giving” nella situazione
  collegata.
content_id: PILL152
content_type: daily_pill
permalink: /pills/day-152-the-gift-that-keeps-on-giving/
canonical: /pills/day-152-the-gift-that-keeps-on-giving/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: The gift that keeps on giving — una espressione da usare davvero
toc: true
level: B2
day: 152
expression_id: EXP152
situation_id: SIT017
grammar_id: GRAM017
category: Idiom
type: idiom
topic: Benefits & Experiences
learning_goal: Imparare a usare naturalmente “the gift that keeps on giving” nella
  situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART017
- GRAMART017
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
