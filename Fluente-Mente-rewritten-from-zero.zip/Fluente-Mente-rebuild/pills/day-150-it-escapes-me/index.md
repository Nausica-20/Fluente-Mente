---
layout: article
title: It escapes me — una espressione da usare davvero
description: Imparare a usare naturalmente “it escapes me” nella situazione collegata.
content_id: PILL150
content_type: daily_pill
permalink: /pills/day-150-it-escapes-me/
canonical: /pills/day-150-it-escapes-me/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: It escapes me — una espressione da usare davvero
toc: true
level: B1+
day: 150
expression_id: EXP150
situation_id: SIT010
grammar_id: GRAM010
category: Everyday expression
type: expression
topic: Memory & Conversation
learning_goal: Imparare a usare naturalmente “it escapes me” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART010
- GRAMART010
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
