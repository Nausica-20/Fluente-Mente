---
layout: article
title: That's on you — una espressione da usare davvero
description: Imparare a usare naturalmente “that's on you” nella situazione collegata.
content_id: PILL111
content_type: daily_pill
permalink: /pills/day-111-thats-on-you/
canonical: /pills/day-111-thats-on-you/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: That's on you — una espressione da usare davvero
toc: true
level: B1+
day: 111
expression_id: EXP111
situation_id: SIT043
grammar_id: GRAM043
category: Everyday expression
type: expression
topic: Responsibility
learning_goal: Imparare a usare naturalmente “that's on you” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART043
- GRAMART043
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
