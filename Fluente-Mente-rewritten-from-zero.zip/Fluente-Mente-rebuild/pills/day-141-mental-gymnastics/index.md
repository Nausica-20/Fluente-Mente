---
layout: article
title: Mental gymnastics — una espressione da usare davvero
description: Imparare a usare naturalmente “mental gymnastics” nella situazione collegata.
content_id: PILL141
content_type: daily_pill
permalink: /pills/day-141-mental-gymnastics/
canonical: /pills/day-141-mental-gymnastics/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Mental gymnastics — una espressione da usare davvero
toc: true
level: B2
day: 141
expression_id: EXP141
situation_id: SIT052
grammar_id: GRAM052
category: Colloquial English
type: noun phrase
topic: Thinking & Problem Solving
learning_goal: Imparare a usare naturalmente “mental gymnastics” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART052
- GRAMART052
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
