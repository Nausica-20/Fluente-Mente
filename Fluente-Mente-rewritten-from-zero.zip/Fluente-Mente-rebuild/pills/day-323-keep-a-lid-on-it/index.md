---
layout: article
title: Keep a lid on it — una espressione da usare davvero
description: Imparare a usare naturalmente “keep a lid on it” nella situazione collegata.
content_id: PILL323
content_type: daily_pill
permalink: /pills/day-323-keep-a-lid-on-it/
canonical: /pills/day-323-keep-a-lid-on-it/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Keep a lid on it — una espressione da usare davvero
toc: true
level: B2
day: 323
expression_id: EXP323
situation_id: SIT032
grammar_id: GRAM032
category: Idiom
type: idiom
topic: Control & Secrets
learning_goal: Imparare a usare naturalmente “keep a lid on it” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART032
- GRAMART032
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
