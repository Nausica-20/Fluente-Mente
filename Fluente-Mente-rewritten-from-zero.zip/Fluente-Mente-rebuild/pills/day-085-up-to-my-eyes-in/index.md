---
layout: article
title: Up to my eyes in — una espressione da usare davvero
description: Imparare a usare naturalmente “up to my eyes in” nella situazione collegata.
content_id: PILL085
content_type: daily_pill
permalink: /pills/day-085-up-to-my-eyes-in/
canonical: /pills/day-085-up-to-my-eyes-in/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Up to my eyes in — una espressione da usare davvero
toc: true
level: B1+
day: 85
expression_id: EXP085
situation_id: SIT052
grammar_id: GRAM052
category: Idiom
type: idiom
topic: Work & Stress
learning_goal: Imparare a usare naturalmente “up to my eyes in” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART052
- GRAMART052
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
