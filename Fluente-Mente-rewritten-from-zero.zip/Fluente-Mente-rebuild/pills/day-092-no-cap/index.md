---
layout: article
title: No cap — una espressione da usare davvero
description: Imparare a usare naturalmente “no cap” nella situazione collegata.
content_id: PILL092
content_type: daily_pill
permalink: /pills/day-092-no-cap/
canonical: /pills/day-092-no-cap/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: No cap — una espressione da usare davvero
toc: true
level: B2
day: 92
expression_id: EXP092
situation_id: SIT048
grammar_id: GRAM048
category: Slang / Internet English
type: slang expression
topic: Internet Culture
learning_goal: Imparare a usare naturalmente “no cap” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART048
- GRAMART048
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
