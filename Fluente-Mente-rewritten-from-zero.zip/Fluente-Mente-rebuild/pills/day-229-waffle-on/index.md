---
layout: article
title: Waffle on — una espressione da usare davvero
description: Imparare a usare naturalmente “waffle on” nella situazione collegata.
content_id: PILL229
content_type: daily_pill
permalink: /pills/day-229-waffle-on/
canonical: /pills/day-229-waffle-on/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Waffle on — una espressione da usare davvero
toc: true
level: B2
day: 229
expression_id: EXP229
situation_id: SIT003
grammar_id: GRAM003
category: British English
type: phrasal verb
topic: Conversation
learning_goal: Imparare a usare naturalmente “waffle on” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART003
- GRAMART003
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
