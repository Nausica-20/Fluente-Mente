---
layout: article
title: Brick by brick — una espressione da usare davvero
description: Imparare a usare naturalmente “brick by brick” nella situazione collegata.
content_id: PILL130
content_type: daily_pill
permalink: /pills/day-130-brick-by-brick/
canonical: /pills/day-130-brick-by-brick/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Brick by brick — una espressione da usare davvero
toc: true
level: B1+
day: 130
expression_id: EXP130
situation_id: SIT039
grammar_id: GRAM039
category: Everyday expression
type: idiom
topic: Progress & Learning
learning_goal: Imparare a usare naturalmente “brick by brick” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART039
- GRAMART039
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
