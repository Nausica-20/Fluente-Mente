---
layout: article
title: You do you — una espressione da usare davvero
description: Imparare a usare naturalmente “you do you” nella situazione collegata.
content_id: PILL275
content_type: daily_pill
permalink: /pills/day-275-you-do-you/
canonical: /pills/day-275-you-do-you/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: You do you — una espressione da usare davvero
toc: true
level: B1+
day: 275
expression_id: EXP275
situation_id: SIT003
grammar_id: GRAM003
category: Colloquial English
type: expression
topic: Choices & Identity
learning_goal: Imparare a usare naturalmente “you do you” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART003
- GRAMART003
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
