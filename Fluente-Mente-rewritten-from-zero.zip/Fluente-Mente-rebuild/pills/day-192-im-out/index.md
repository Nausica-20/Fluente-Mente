---
layout: article
title: I'm out — una espressione da usare davvero
description: Imparare a usare naturalmente “I'm out” nella situazione collegata.
content_id: PILL192
content_type: daily_pill
permalink: /pills/day-192-im-out/
canonical: /pills/day-192-im-out/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: I'm out — una espressione da usare davvero
toc: true
level: B1+
day: 192
expression_id: EXP192
situation_id: SIT010
grammar_id: GRAM010
category: Everyday expression
type: expression
topic: Choices & Conversation
learning_goal: Imparare a usare naturalmente “I'm out” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART010
- GRAMART010
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
