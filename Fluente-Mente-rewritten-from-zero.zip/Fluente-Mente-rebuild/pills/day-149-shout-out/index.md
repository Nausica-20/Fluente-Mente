---
layout: article
title: Shout-out — una espressione da usare davvero
description: Imparare a usare naturalmente “shout-out” nella situazione collegata.
content_id: PILL149
content_type: daily_pill
permalink: /pills/day-149-shout-out/
canonical: /pills/day-149-shout-out/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Shout-out — una espressione da usare davvero
toc: true
level: B2
day: 149
expression_id: EXP149
situation_id: SIT007
grammar_id: GRAM007
category: Modern English
type: noun
topic: Social Media & Praise
learning_goal: Imparare a usare naturalmente “shout-out” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART007
- GRAMART007
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
