---
layout: article
title: Hot on the heels of — una espressione da usare davvero
description: Imparare a usare naturalmente “hot on the heels of” nella situazione
  collegata.
content_id: PILL070
content_type: daily_pill
permalink: /pills/day-070-hot-on-the-heels-of/
canonical: /pills/day-070-hot-on-the-heels-of/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Hot on the heels of — una espressione da usare davvero
toc: true
level: B2
day: 70
expression_id: EXP070
situation_id: SIT001
grammar_id: GRAM001
category: Idiom
type: idiom
topic: Time & Events
learning_goal: Imparare a usare naturalmente “hot on the heels of” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART001
- GRAMART001
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
