---
layout: article
title: Take the biscuit — una espressione da usare davvero
description: Imparare a usare naturalmente “take the biscuit” nella situazione collegata.
content_id: PILL235
content_type: daily_pill
permalink: /pills/day-235-take-the-biscuit/
canonical: /pills/day-235-take-the-biscuit/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Take the biscuit — una espressione da usare davvero
toc: true
level: B2
day: 235
expression_id: EXP235
situation_id: SIT028
grammar_id: GRAM028
category: British English
type: idiom
topic: Reactions & Opinions
learning_goal: Imparare a usare naturalmente “take the biscuit” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART028
- GRAMART028
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
