---
layout: article
title: Out of your depth — una espressione da usare davvero
description: Imparare a usare naturalmente “out of your depth” nella situazione collegata.
content_id: PILL335
content_type: daily_pill
permalink: /pills/day-335-out-of-your-depth/
canonical: /pills/day-335-out-of-your-depth/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Out of your depth — una espressione da usare davvero
toc: true
level: B1+
day: 335
expression_id: EXP335
situation_id: SIT051
grammar_id: GRAM051
category: Idiom
type: idiom
topic: Challenges & Work
learning_goal: Imparare a usare naturalmente “out of your depth” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART051
- GRAMART051
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
