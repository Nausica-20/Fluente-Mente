---
layout: article
title: Lay it on thick — una espressione da usare davvero
description: Imparare a usare naturalmente “lay it on thick” nella situazione collegata.
content_id: PILL127
content_type: daily_pill
permalink: /pills/day-127-lay-it-on-thick/
canonical: /pills/day-127-lay-it-on-thick/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Lay it on thick — una espressione da usare davvero
toc: true
level: B2
day: 127
expression_id: EXP127
situation_id: SIT002
grammar_id: GRAM002
category: Idiom
type: idiom
topic: Social English
learning_goal: Imparare a usare naturalmente “lay it on thick” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART002
- GRAMART002
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
