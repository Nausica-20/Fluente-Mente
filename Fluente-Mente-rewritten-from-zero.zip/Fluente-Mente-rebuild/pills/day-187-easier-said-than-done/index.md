---
layout: article
title: Easier said than done — una espressione da usare davvero
description: Imparare a usare naturalmente “easier said than done” nella situazione
  collegata.
content_id: PILL187
content_type: daily_pill
permalink: /pills/day-187-easier-said-than-done/
canonical: /pills/day-187-easier-said-than-done/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Easier said than done — una espressione da usare davvero
toc: true
level: B1+
day: 187
expression_id: EXP187
situation_id: SIT015
grammar_id: GRAM015
category: Idiom
type: idiom
topic: Advice & Challenges
learning_goal: Imparare a usare naturalmente “easier said than done” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART015
- GRAMART015
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
