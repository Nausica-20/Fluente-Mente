---
layout: article
title: Try it on — una espressione da usare davvero
description: Imparare a usare naturalmente “try it on” nella situazione collegata.
content_id: PILL051
content_type: daily_pill
permalink: /pills/day-051-try-it-on/
canonical: /pills/day-051-try-it-on/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Try it on — una espressione da usare davvero
toc: true
level: B2
day: 51
expression_id: EXP051
situation_id: SIT002
grammar_id: GRAM002
category: British English
type: idiom
topic: Social Behaviour
learning_goal: Imparare a usare naturalmente “try it on” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART002
- GRAMART002
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
