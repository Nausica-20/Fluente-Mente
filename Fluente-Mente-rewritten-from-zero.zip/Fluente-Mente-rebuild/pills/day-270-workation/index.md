---
layout: article
title: Workation — una espressione da usare davvero
description: Imparare a usare naturalmente “workation” nella situazione collegata.
content_id: PILL270
content_type: daily_pill
permalink: /pills/day-270-workation/
canonical: /pills/day-270-workation/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Workation — una espressione da usare davvero
toc: true
level: B2
day: 270
expression_id: EXP270
situation_id: SIT051
grammar_id: GRAM051
category: New word / neologism
type: noun
topic: Work & Travel
learning_goal: Imparare a usare naturalmente “workation” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART051
- GRAMART051
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
