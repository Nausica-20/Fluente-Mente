---
layout: article
title: Make your hair stand on end — una espressione da usare davvero
description: Imparare a usare naturalmente “make your hair stand on end” nella situazione
  collegata.
content_id: PILL134
content_type: daily_pill
permalink: /pills/day-134-make-your-hair-stand-on-end/
canonical: /pills/day-134-make-your-hair-stand-on-end/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Make your hair stand on end — una espressione da usare davvero
toc: true
level: B2
day: 134
expression_id: EXP134
situation_id: SIT044
grammar_id: GRAM044
category: Idiom
type: idiom
topic: Feelings
learning_goal: Imparare a usare naturalmente “make your hair stand on end” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART044
- GRAMART044
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
