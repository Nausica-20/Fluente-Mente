---
layout: article
title: Fat chance — una espressione da usare davvero
description: Imparare a usare naturalmente “fat chance” nella situazione collegata.
content_id: PILL307
content_type: daily_pill
permalink: /pills/day-307-fat-chance/
canonical: /pills/day-307-fat-chance/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Fat chance — una espressione da usare davvero
toc: true
level: B1+
day: 307
expression_id: EXP307
situation_id: SIT008
grammar_id: GRAM008
category: Colloquial English
type: expression
topic: Possibility & Reactions
learning_goal: Imparare a usare naturalmente “fat chance” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART008
- GRAMART008
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
