---
layout: article
title: Speak someone's language — una espressione da usare davvero
description: Imparare a usare naturalmente “speak someone's language” nella situazione
  collegata.
content_id: PILL032
content_type: daily_pill
permalink: /pills/day-032-speak-someones-language/
canonical: /pills/day-032-speak-someones-language/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Speak someone's language — una espressione da usare davvero
toc: true
level: B1
day: 32
expression_id: EXP032
situation_id: SIT010
grammar_id: GRAM010
category: Idiom
type: idiom
topic: Communication
learning_goal: Imparare a usare naturalmente “speak someone's language” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART010
- GRAMART010
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
