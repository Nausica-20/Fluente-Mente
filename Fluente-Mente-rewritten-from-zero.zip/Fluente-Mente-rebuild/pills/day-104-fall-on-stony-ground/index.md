---
layout: article
title: Fall on stony ground — una espressione da usare davvero
description: Imparare a usare naturalmente “fall on stony ground” nella situazione
  collegata.
content_id: PILL104
content_type: daily_pill
permalink: /pills/day-104-fall-on-stony-ground/
canonical: /pills/day-104-fall-on-stony-ground/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Fall on stony ground — una espressione da usare davvero
toc: true
level: B2
day: 104
expression_id: EXP104
situation_id: SIT025
grammar_id: GRAM025
category: Idiom
type: idiom
topic: Communication
learning_goal: Imparare a usare naturalmente “fall on stony ground” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART025
- GRAMART025
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
