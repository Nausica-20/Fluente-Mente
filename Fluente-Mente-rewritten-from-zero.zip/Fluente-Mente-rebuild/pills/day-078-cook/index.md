---
layout: article
title: Cook — una espressione da usare davvero
description: Imparare a usare naturalmente “cook” nella situazione collegata.
content_id: PILL078
content_type: daily_pill
permalink: /pills/day-078-cook/
canonical: /pills/day-078-cook/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Cook — una espressione da usare davvero
toc: true
level: B2
day: 78
expression_id: EXP078
situation_id: SIT048
grammar_id: GRAM048
category: Slang / Internet English
type: verb
topic: Internet Culture
learning_goal: Imparare a usare naturalmente “cook” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART048
- GRAMART048
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
