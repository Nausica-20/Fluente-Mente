---
layout: article
title: Shrinkflation — una espressione da usare davvero
description: Imparare a usare naturalmente “shrinkflation” nella situazione collegata.
content_id: PILL362
content_type: daily_pill
permalink: /pills/day-362-shrinkflation/
canonical: /pills/day-362-shrinkflation/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Shrinkflation — una espressione da usare davvero
toc: true
level: B2
day: 362
expression_id: EXP362
situation_id: SIT014
grammar_id: GRAM014
category: New word / neologism
type: noun
topic: Money & Consumer Life
learning_goal: Imparare a usare naturalmente “shrinkflation” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART014
- GRAMART014
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
