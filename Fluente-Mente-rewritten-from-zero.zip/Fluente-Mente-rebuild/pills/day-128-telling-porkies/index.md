---
layout: article
title: Telling porkies — una espressione da usare davvero
description: Imparare a usare naturalmente “telling porkies” nella situazione collegata.
content_id: PILL128
content_type: daily_pill
permalink: /pills/day-128-telling-porkies/
canonical: /pills/day-128-telling-porkies/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Telling porkies — una espressione da usare davvero
toc: true
level: B2
day: 128
expression_id: EXP128
situation_id: SIT002
grammar_id: GRAM002
category: British English
type: idiom
topic: Honesty & Social English
learning_goal: Imparare a usare naturalmente “telling porkies” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART002
- GRAMART002
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
