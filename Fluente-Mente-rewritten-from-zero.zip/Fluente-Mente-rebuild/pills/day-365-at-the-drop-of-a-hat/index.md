---
layout: article
title: At the drop of a hat — una espressione da usare davvero
description: Imparare a usare naturalmente “at the drop of a hat” nella situazione
  collegata.
content_id: PILL365
content_type: daily_pill
permalink: /pills/day-365-at-the-drop-of-a-hat/
canonical: /pills/day-365-at-the-drop-of-a-hat/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: At the drop of a hat — una espressione da usare davvero
toc: true
level: B2
day: 365
expression_id: EXP365
situation_id: SIT005
grammar_id: GRAM005
category: Idiom
type: idiom
topic: Time & Decisions
learning_goal: Imparare a usare naturalmente “at the drop of a hat” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART005
- GRAMART005
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
