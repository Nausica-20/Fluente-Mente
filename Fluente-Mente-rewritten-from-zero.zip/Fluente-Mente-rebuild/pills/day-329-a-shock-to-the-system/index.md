---
layout: article
title: A shock to the system — una espressione da usare davvero
description: Imparare a usare naturalmente “a shock to the system” nella situazione
  collegata.
content_id: PILL329
content_type: daily_pill
permalink: /pills/day-329-a-shock-to-the-system/
canonical: /pills/day-329-a-shock-to-the-system/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: A shock to the system — una espressione da usare davvero
toc: true
level: B2
day: 329
expression_id: EXP329
situation_id: SIT009
grammar_id: GRAM009
category: Idiom
type: noun phrase
topic: Change & Reactions
learning_goal: Imparare a usare naturalmente “a shock to the system” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART009
- GRAMART009
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
