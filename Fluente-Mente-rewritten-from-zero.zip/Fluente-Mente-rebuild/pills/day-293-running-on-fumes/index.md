---
layout: article
title: Running on fumes — una espressione da usare davvero
description: Imparare a usare naturalmente “running on fumes” nella situazione collegata.
content_id: PILL293
content_type: daily_pill
permalink: /pills/day-293-running-on-fumes/
canonical: /pills/day-293-running-on-fumes/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Running on fumes — una espressione da usare davvero
toc: true
level: B2
day: 293
expression_id: EXP293
situation_id: SIT050
grammar_id: GRAM050
category: Idiom
type: idiom
topic: Energy & Work
learning_goal: Imparare a usare naturalmente “running on fumes” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART050
- GRAMART050
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
