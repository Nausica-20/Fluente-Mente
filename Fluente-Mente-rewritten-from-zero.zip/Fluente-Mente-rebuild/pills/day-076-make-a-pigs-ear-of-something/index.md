---
layout: article
title: Make a pig's ear of something — una espressione da usare davvero
description: Imparare a usare naturalmente “make a pig's ear of something” nella situazione
  collegata.
content_id: PILL076
content_type: daily_pill
permalink: /pills/day-076-make-a-pigs-ear-of-something/
canonical: /pills/day-076-make-a-pigs-ear-of-something/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Make a pig's ear of something — una espressione da usare davvero
toc: true
level: B2
day: 76
expression_id: EXP076
situation_id: SIT023
grammar_id: GRAM023
category: British English
type: idiom
topic: Mistakes & Problems
learning_goal: Imparare a usare naturalmente “make a pig's ear of something” nella
  situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART023
- GRAMART023
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
