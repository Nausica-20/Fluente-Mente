---
layout: article
title: Can't put my finger on it — una espressione da usare davvero
description: Imparare a usare naturalmente “can't put my finger on it” nella situazione
  collegata.
content_id: PILL029
content_type: daily_pill
permalink: /pills/day-029-cant-put-my-finger-on-it/
canonical: /pills/day-029-cant-put-my-finger-on-it/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Can't put my finger on it — una espressione da usare davvero
toc: true
level: B2
day: 29
expression_id: EXP029
situation_id: SIT010
grammar_id: GRAM010
category: Idiom
type: idiom
topic: Feelings & Reactions
learning_goal: Imparare a usare naturalmente “can't put my finger on it” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART010
- GRAMART010
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
