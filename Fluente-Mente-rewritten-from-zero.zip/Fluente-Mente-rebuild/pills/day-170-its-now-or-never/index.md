---
layout: article
title: It's now or never — una espressione da usare davvero
description: Imparare a usare naturalmente “it's now or never” nella situazione collegata.
content_id: PILL170
content_type: daily_pill
permalink: /pills/day-170-its-now-or-never/
canonical: /pills/day-170-its-now-or-never/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: It's now or never — una espressione da usare davvero
toc: true
level: B1+
day: 170
expression_id: EXP170
situation_id: SIT014
grammar_id: GRAM014
category: Idiom
type: idiom
topic: Decisions & Opportunities
learning_goal: Imparare a usare naturalmente “it's now or never” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART014
- GRAMART014
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
