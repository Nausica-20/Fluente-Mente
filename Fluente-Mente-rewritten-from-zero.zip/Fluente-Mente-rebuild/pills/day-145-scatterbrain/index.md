---
layout: article
title: Scatterbrain — una espressione da usare davvero
description: Imparare a usare naturalmente “scatterbrain” nella situazione collegata.
content_id: PILL145
content_type: daily_pill
permalink: /pills/day-145-scatterbrain/
canonical: /pills/day-145-scatterbrain/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Scatterbrain — una espressione da usare davvero
toc: true
level: B2
day: 145
expression_id: EXP145
situation_id: SIT003
grammar_id: GRAM003
category: Colloquial English
type: noun
topic: Personality
learning_goal: Imparare a usare naturalmente “scatterbrain” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART003
- GRAMART003
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
