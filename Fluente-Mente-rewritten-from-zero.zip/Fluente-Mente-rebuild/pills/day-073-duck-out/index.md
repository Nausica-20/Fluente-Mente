---
layout: article
title: Duck out — una espressione da usare davvero
description: Imparare a usare naturalmente “duck out” nella situazione collegata.
content_id: PILL073
content_type: daily_pill
permalink: /pills/day-073-duck-out/
canonical: /pills/day-073-duck-out/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Duck out — una espressione da usare davvero
toc: true
level: B1
day: 73
expression_id: EXP073
situation_id: SIT002
grammar_id: GRAM002
category: Colloquial English
type: phrasal_verb
topic: Social Life
learning_goal: Imparare a usare naturalmente “duck out” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART002
- GRAMART002
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
