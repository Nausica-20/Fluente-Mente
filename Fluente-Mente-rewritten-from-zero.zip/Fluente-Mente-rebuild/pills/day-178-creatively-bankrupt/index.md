---
layout: article
title: Creatively bankrupt — una espressione da usare davvero
description: Imparare a usare naturalmente “creatively bankrupt” nella situazione
  collegata.
content_id: PILL178
content_type: daily_pill
permalink: /pills/day-178-creatively-bankrupt/
canonical: /pills/day-178-creatively-bankrupt/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Creatively bankrupt — una espressione da usare davvero
toc: true
level: B2
day: 178
expression_id: EXP178
situation_id: SIT050
grammar_id: GRAM050
category: Colloquial English
type: adjective phrase
topic: Creativity & Work
learning_goal: Imparare a usare naturalmente “creatively bankrupt” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART050
- GRAMART050
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
