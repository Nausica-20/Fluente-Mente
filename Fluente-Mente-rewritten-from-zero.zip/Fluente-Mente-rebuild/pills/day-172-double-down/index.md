---
layout: article
title: Double down — una espressione da usare davvero
description: Imparare a usare naturalmente “double down” nella situazione collegata.
content_id: PILL172
content_type: daily_pill
permalink: /pills/day-172-double-down/
canonical: /pills/day-172-double-down/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Double down — una espressione da usare davvero
toc: true
level: B2
day: 172
expression_id: EXP172
situation_id: SIT008
grammar_id: GRAM008
category: Phrasal verb
type: verb
topic: Decisions & Strategy
learning_goal: Imparare a usare naturalmente “double down” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART008
- GRAMART008
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
