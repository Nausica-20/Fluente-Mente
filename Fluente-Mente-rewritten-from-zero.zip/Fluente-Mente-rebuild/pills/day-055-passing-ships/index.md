---
layout: article
title: Passing ships — una espressione da usare davvero
description: Imparare a usare naturalmente “passing ships” nella situazione collegata.
content_id: PILL055
content_type: daily_pill
permalink: /pills/day-055-passing-ships/
canonical: /pills/day-055-passing-ships/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Passing ships — una espressione da usare davvero
toc: true
level: B2
day: 55
expression_id: EXP055
situation_id: SIT005
grammar_id: GRAM005
category: Idiom
type: idiom
topic: Relationships
learning_goal: Imparare a usare naturalmente “passing ships” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART005
- GRAMART005
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
