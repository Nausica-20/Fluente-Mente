---
layout: article
title: An old hand — una espressione da usare davvero
description: Imparare a usare naturalmente “an old hand” nella situazione collegata.
content_id: PILL342
content_type: daily_pill
permalink: /pills/day-342-an-old-hand/
canonical: /pills/day-342-an-old-hand/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: An old hand — una espressione da usare davvero
toc: true
level: B2
day: 342
expression_id: EXP342
situation_id: SIT051
grammar_id: GRAM051
category: Idiom
type: noun phrase
topic: Work & Experience
learning_goal: Imparare a usare naturalmente “an old hand” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART051
- GRAMART051
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
