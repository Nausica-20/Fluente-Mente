---
layout: article
title: A knees-up — una espressione da usare davvero
description: Imparare a usare naturalmente “a knees-up” nella situazione collegata.
content_id: PILL246
content_type: daily_pill
permalink: /pills/day-246-a-knees-up/
canonical: /pills/day-246-a-knees-up/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: A knees-up — una espressione da usare davvero
toc: true
level: B2
day: 246
expression_id: EXP246
situation_id: SIT002
grammar_id: GRAM002
category: British English
type: noun phrase
topic: Social Life
learning_goal: Imparare a usare naturalmente “a knees-up” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART002
- GRAMART002
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
