---
layout: article
title: Do the trick — una espressione da usare davvero
description: Imparare a usare naturalmente “do the trick” nella situazione collegata.
content_id: PILL005
content_type: daily_pill
permalink: /pills/day-005-do-the-trick/
canonical: /pills/day-005-do-the-trick/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Do the trick — una espressione da usare davvero
toc: true
level: B1
day: 5
expression_id: EXP005
situation_id: SIT037
grammar_id: GRAM037
category: Everyday expression
type: idiom
topic: Problem Solving
learning_goal: Imparare a usare naturalmente “do the trick” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART037
- GRAMART037
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
