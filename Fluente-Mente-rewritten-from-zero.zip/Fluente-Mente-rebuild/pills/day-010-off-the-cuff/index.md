---
layout: article
title: Off the cuff — una espressione da usare davvero
description: Imparare a usare naturalmente “off the cuff” nella situazione collegata.
content_id: PILL010
content_type: daily_pill
permalink: /pills/day-010-off-the-cuff/
canonical: /pills/day-010-off-the-cuff/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Off the cuff — una espressione da usare davvero
toc: true
level: B1+
day: 10
expression_id: EXP010
situation_id: SIT051
grammar_id: GRAM051
category: Idiom
type: idiom
topic: Speaking
learning_goal: Imparare a usare naturalmente “off the cuff” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART051
- GRAMART051
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
