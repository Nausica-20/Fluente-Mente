---
layout: article
title: Not gonna lie — una espressione da usare davvero
description: Imparare a usare naturalmente “not gonna lie” nella situazione collegata.
content_id: PILL242
content_type: daily_pill
permalink: /pills/day-242-not-gonna-lie/
canonical: /pills/day-242-not-gonna-lie/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Not gonna lie — una espressione da usare davvero
toc: true
level: B1+
day: 242
expression_id: EXP242
situation_id: SIT047
grammar_id: GRAM047
category: Slang / Internet English
type: expression
topic: Conversation & Internet
learning_goal: Imparare a usare naturalmente “not gonna lie” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART047
- GRAMART047
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
