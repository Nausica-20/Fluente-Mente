---
layout: article
title: Not see hide nor hair — una espressione da usare davvero
description: Imparare a usare naturalmente “not see hide nor hair” nella situazione
  collegata.
content_id: PILL183
content_type: daily_pill
permalink: /pills/day-183-not-see-hide-nor-hair/
canonical: /pills/day-183-not-see-hide-nor-hair/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Not see hide nor hair — una espressione da usare davvero
toc: true
level: B2
day: 183
expression_id: EXP183
situation_id: SIT007
grammar_id: GRAM007
category: British English
type: idiom
topic: People & Communication
learning_goal: Imparare a usare naturalmente “not see hide nor hair” nella situazione
  collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART007
- GRAMART007
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
