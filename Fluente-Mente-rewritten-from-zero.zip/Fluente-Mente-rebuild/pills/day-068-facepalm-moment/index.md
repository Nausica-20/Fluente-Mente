---
layout: article
title: Facepalm moment — una espressione da usare davvero
description: Imparare a usare naturalmente “facepalm moment” nella situazione collegata.
content_id: PILL068
content_type: daily_pill
permalink: /pills/day-068-facepalm-moment/
canonical: /pills/day-068-facepalm-moment/
status: planned
index: false
follow: false
sitemap: false
evergreen: true
original_content: true
section_label: Pillola del giorno
section_url: /pills/
breadcrumb_current: Facepalm moment — una espressione da usare davvero
toc: true
level: B2
day: 68
expression_id: EXP068
situation_id: SIT051
grammar_id: GRAM051
category: Modern English
type: noun phrase
topic: Reactions & Mistakes
learning_goal: Imparare a usare naturalmente “facepalm moment” nella situazione collegata.
babbel:
  enabled: true
  cta_level: soft
related_content:
- SITART051
- GRAMART051
---

<!-- EDITORIAL CONTENT PLACEHOLDER: generated from the canonical registry. Replace this body during article production. -->
